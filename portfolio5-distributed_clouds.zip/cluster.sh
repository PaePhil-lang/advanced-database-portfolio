set -e
B=/usr/lib/postgresql/16/bin
D=/tmp/p5
for p in 5501 5502 5503 5511 5512; do su postgres -c "$B/pg_ctl -D $D/n$p stop -m immediate" >/dev/null 2>&1 || true; done
rm -rf $D; mkdir -p $D; chown postgres $D
# primary (Ceddi Plaza data centre) on 5501
su postgres -c "$B/initdb -D $D/n5501 -A trust >/dev/null"
cat >> $D/n5501/postgresql.conf <<C
port = 5501
unix_socket_directories = '$D'
listen_addresses = ''
wal_level = replica
wal_log_hints = on
wal_keep_size = '256MB'
max_wal_senders = 10
hot_standby = on
cluster_name = 'primary_ceddi'
synchronous_standby_names = ''
log_line_prefix = '%m [%p] '
C
echo "local replication all trust" >> $D/n5501/pg_hba.conf
su postgres -c "$B/pg_ctl -D $D/n5501 -l $D/n5501.log start -w >/dev/null"
# two standbys via pg_basebackup
for p in 5502 5503; do
  su postgres -c "$B/pg_basebackup -h $D -p 5501 -D $D/n$p -R -X stream -C -S slot_$p >/dev/null"
  sed -i "s/^port = 5501/port = $p/; s/cluster_name = 'primary_ceddi'/cluster_name = 'standby_$p'/" $D/n$p/postgresql.conf
  sed -i "s/primary_conninfo = '/primary_conninfo = 'application_name=standby_$p /" $D/n$p/postgresql.auto.conf
  su postgres -c "$B/pg_ctl -D $D/n$p -l $D/n$p.log start -w >/dev/null"
done
echo up
# two shard nodes
for p in 5511 5512; do
  su postgres -c "$B/initdb -D $D/n$p -A trust >/dev/null"
  printf "port = $p\nunix_socket_directories = '$D'\nlisten_addresses = ''\ncluster_name = 'shard_$p'\n" >> $D/n$p/postgresql.conf
  su postgres -c "$B/pg_ctl -D $D/n$p -l $D/n$p.log start -w >/dev/null"
done
echo shards up
