import subprocess, time, sys
from tx import Sess, Scenario, render
B='/usr/lib/postgresql/16/bin'; D='/tmp/p5'
def sh(cmd): r = subprocess.run(['bash','-c',cmd], capture_output=True, text=True); return (r.stdout + r.stderr).strip().split('\n') if (r.stdout+r.stderr).strip() else []
def pgsql(port, sql, db='idsdist'): return sh(f"su postgres -c \"psql -h {D} -p {port} -d {db} -Atc \\\"{sql}\\\"\"")
def osrun(sc, key, cmd, shown=None):
    sc.step += 1; out = sh(cmd); sc.log.append(dict(step=sc.step, sess=key, sql=shown or cmd, out=out, state='ok'))
def go(key, title, cols, prompts, body):
    ss = {k: Sess(k, lab, port) for k, lab, port in cols if port}
    sc = Scenario(title, ss); sc.prompts = prompts; body(sc)
    for s in ss.values(): s.close()
    render(sc, f'img/{key}.png', [(k, lab) for k, lab, _ in cols]); open(f'img/{key}.txt','w').write(sc.text()); print(sc.text()); print()
BAL = "SELECT amount_paid, balance, payment_status\nFROM v_invoice_balance WHERE invoice_id = 1;"
PAY = lambda amt, ref: f"INSERT INTO payment (invoice_id, amount, method, reference, received_by)\nVALUES (1, {amt}, 'POS', '{ref}', 5);"
P = ('P','Primary :5501 (Ceddi Plaza)',5501); S2 = ('S','Standby :5502 (same city, sync candidate)',5502); S3 = ('R','Standby :5503 (remote DR, 5 s apply delay)',5503)
PR = {'P':'primary=# ','S':'standby2=# ','R':'standby3=# ','M':'primary=# ','O':'$ '}

def r1(s):
    s.run('P', "SELECT application_name, state, sync_state, sent_lsn, replay_lsn\nFROM pg_stat_replication ORDER BY 1;")
    s.run('P', "INSERT INTO patient (hospital_no, first_name, last_name, date_of_birth, sex, phone, registered_branch_id)\nVALUES ('IDS-000777', 'Halima', 'Danjuma', '1992-05-14', 'F', '+2348061230777', 1)\nRETURNING patient_id, hospital_no;")
    s.run('S', "SELECT pg_is_in_recovery() AS standby, hospital_no, first_name, last_name\nFROM patient WHERE hospital_no = 'IDS-000777';")
    s.run('S', "UPDATE patient SET phone = '+2348061239999' WHERE hospital_no = 'IDS-000777';")
    s.run('S', "SELECT status, slot_name, sender_port, latest_end_lsn FROM pg_stat_wal_receiver;")
def c1(s):
    s.run('P', PAY(15000, 'POS-C1-01'))
    s.run('P', "SELECT amount_paid, balance FROM v_invoice_balance WHERE invoice_id = 1;")
    s.run('R', BAL)
    s.run('R', "SELECT pg_last_wal_receive_lsn() AS received_lsn,\n       pg_last_wal_replay_lsn() AS applied_lsn;")
    s.note('Wait 6 seconds.'); time.sleep(6)
    s.run('R', BAL)
def c2(s):
    s.run('P', "SELECT application_name, sync_state FROM pg_stat_replication ORDER BY 1;")
    s.run('P', "SET synchronous_commit = remote_apply;")
    s.run('P', PAY(10000, 'POS-C2-01'))
    s.run('S', BAL)
def c3(s):
    s.wait_text = '[WAITING] commit is waiting for a synchronous standby to confirm'
    s.resume_text = '[RESUMED] a standby confirmed, commit returns'
    osrun(s, 'O', f"su postgres -c '{B}/pg_ctl -D {D}/n5502 stop -m fast'", "pg_ctl -D n5502 stop -m fast    # sync standby goes down")
    s.run('P', PAY(5000, 'POS-C3-01'), wait=3)
    s.run('M', "SELECT pid, state, wait_event_type, wait_event, left(query, 26) AS query\nFROM pg_stat_activity WHERE wait_event = 'SyncRep';")
    s.run('M', "ALTER SYSTEM SET synchronous_standby_names = 'ANY 1 (standby_5502, standby_5503)';")
    s.run('M', "SELECT pg_reload_conf();")
    s.poll('P', 5)
    osrun(s, 'O', f"su postgres -c '{B}/pg_ctl -D {D}/n5502 -l {D}/n5502.log start -w'", "pg_ctl -D n5502 start    # standby back, catches up from its slot")
    time.sleep(1)
    s.run('M', "SELECT application_name, state, sync_state FROM pg_stat_replication ORDER BY 1;")
ALL = {
 'r1_replication': ('R1 Streaming replication: one primary, two hot standbys', [P, S2], r1, None),
 'c1_stale_read': ('C1 Eventual consistency: stale read on a lagging replica', [P, S3], c1, "ALTER SYSTEM SET recovery_min_apply_delay = '5s'"),
 'c2_read_your_writes': ('C2 Read-your-writes with synchronous_commit = remote_apply', [P, S2], c2, 'SYNC'),
 'c3_sync_blocks': ('C3 CAP in practice: sync standby lost, commits wait, quorum restores service', [P, ('M','Primary :5501, DBA session',5501), ('O','Shell (operator)',None)], c3, 'SYNC'),
}
sh(f"su postgres -c '{B}/pg_ctl -D {D}/n5502 -l {D}/n5502.log start -w'"); time.sleep(1)
pgsql(5501, "DELETE FROM payment"); pgsql(5501, "ALTER SYSTEM RESET synchronous_standby_names"); pgsql(5501, "SELECT pg_reload_conf()")
pgsql(5503, "ALTER SYSTEM RESET recovery_min_apply_delay"); pgsql(5503, "SELECT pg_reload_conf()")
pgsql(5501, "DELETE FROM patient WHERE hospital_no = 'IDS-000777'"); time.sleep(1)
for k in (sys.argv[1:] or ALL):
    title, cols, body, setup = ALL[k]
    if setup == 'SYNC':
        pgsql(5501, "ALTER SYSTEM SET synchronous_standby_names = 'FIRST 1 (standby_5502)'"); pgsql(5501, "SELECT pg_reload_conf()"); time.sleep(1)
    elif setup:
        pgsql(5503, setup); pgsql(5503, "SELECT pg_reload_conf()"); time.sleep(1)
    go(k, title, cols, PR, body)
