import subprocess, threading, queue, time, re, json
from PIL import Image, ImageDraw, ImageFont

class Sess:
    def __init__(self, name, label, port=5501, db='idsdist'):
        self.name, self.label = name, label
        self.p = subprocess.Popen(['su','postgres','-c',f'stdbuf -oL -eL psql -h /tmp/p5 -p {port} -d {db} -X -P pager=off -P footer=on'],
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        self.q = queue.Queue()
        threading.Thread(target=self._rd, daemon=True).start()
        self.pending = None
    def _rd(self):
        for line in self.p.stdout: self.q.put(line.rstrip('\n'))
    def send(self, sql):
        self.p.stdin.write(sql.strip() + "\n\\echo __END__\n"); self.p.stdin.flush()
    def collect(self, timeout):
        lines, end = [], time.time() + timeout
        while True:
            try: l = self.q.get(timeout=max(0.01, end - time.time()))
            except queue.Empty: return lines, False
            if l == '__END__': return lines, True
            lines.append(re.sub(r'^psql:<stdin>:\d+: ', '', l))
            if time.time() > end and self.q.empty(): return lines, False
    def close(self):
        try: self.p.stdin.close(); self.p.wait(3)
        except Exception: self.p.kill()

class Scenario:
    def __init__(self, title, sessions):
        self.title = title; self.s = sessions; self.log = []; self.step = 0
    def run(self, key, sql, wait=1.5):
        s = self.s[key]; self.step += 1; t0 = time.time()
        s.send(sql); out, done = s.collect(wait)
        e = dict(step=self.step, sess=key, sql=sql.strip(), out=[l for l in out if l.strip() != ''] if False else out, state='ok' if done else 'waiting')
        if done and any(l.startswith('ERROR') for l in out): e['state'] = 'error'
        if not done: s.pending = (e, t0)
        self.log.append(e); return e
    def poll(self, key, wait=5):
        s = self.s[key]; e0, t0 = s.pending
        out, done = s.collect(wait)
        self.step += 1
        e = dict(step=self.step, sess=key, sql=None, out=out, state='resumed', waited=round(time.time()-t0,1))
        if any(l.startswith('ERROR') for l in out): e['state'] = 'resumed-error'
        s.pending = None if done else s.pending
        self.log.append(e); return e
    def note(self, text):
        self.step += 1; self.log.append(dict(step=self.step, sess=None, sql=None, out=[text], state='note'))
    def text(self):
        t = [f'## {self.title}']
        for e in self.log:
            who = e['sess'] or '--'
            if e['sql']: t.append(f"[t{e['step']}] {who}> {e['sql']}")
            if e['state']=='waiting': t.append(f"[t{e['step']}] {who}  ... blocked, waiting for lock")
            if e['state'].startswith('resumed'): t.append(f"[t{e['step']}] {who}  ... resumed after {e['waited']} s")
            t += [f"      {l}" for l in e['out']]
        return '\n'.join(t)

MONO = '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
MONOB = '/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf'
SANSB = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def wrap(s, n):
    out = []
    for line in s.split('\n'):
        while len(line) > n: out.append(line[:n]); line = '  ' + line[n:]
        out.append(line)
    return out

def render(sc, path, cols, width=None):
    f = ImageFont.truetype(MONO, 14); fb = ImageFont.truetype(MONOB, 14); ft = ImageFont.truetype(SANSB, 17); fs = ImageFont.truetype(MONO, 13)
    gut, pad, lh = 64, 14, 19
    cw = f.getlength('M')
    need = {}
    for e in sc.log:
        if e['sess'] is None: continue
        L = [len(x) for x in e['out']] + [len(x) + 8 for x in (e['sql'] or '').split('\n')] + [56]
        need[e['sess']] = max(need.get(e['sess'], 40), min(max(L), 84))
    colws = [int(need.get(k, 60) * cw + 34) for k, _ in cols]
    width = gut + 2*pad + sum(colws)
    xs = [gut + pad + sum(colws[:i]) for i in range(len(cols))]
    nchars = [need.get(k, 60) for k, _ in cols]
    BG, BAR, FG, SQL, DIM, ERR, WAIT, OK, RB, GRID = '#1b1e23', '#2b2f36', '#d7dae0', '#7fd1ff', '#8b929c', '#ff7b72', '#f2cc60', '#7ee787', '#ffa657', '#30353d'
    # layout pass
    rows = []
    for e in sc.log:
        L = []
        if e['state']=='note':
            rows.append(('note', e, wrap(e['out'][0], int((width-gut-2*pad)//cw)))); continue
        nchar = nchars[[k for k,_ in cols].index(e['sess'])]
        if e['sql']:
            for i, l in enumerate(wrap(e['sql'], nchar - 8)): L.append(('sql', (getattr(sc,'prompts',{}).get(e['sess'],'idstx=# ') if i==0 else ' '*len(getattr(sc,'prompts',{}).get(e['sess'],'idstx=# '))) + l))
        if e['state']=='waiting': L.append(('wait', getattr(sc, 'wait_text', '[WAITING] blocked by a lock held by another session')))
        if e['state'].startswith('resumed'): L.append(('wait', getattr(sc, 'resume_text', '[RESUMED] lock released, statement completes') + f" (waited {e['waited']} s)"))
        inerr = False
        for l in e['out']:
            if l.startswith('ERROR'): inerr = True
            for w in wrap(l, nchar):
                k = 'err' if inerr else 'out'
                if l.strip() in ('COMMIT','ROLLBACK'): k = 'ok' if l.strip()=='COMMIT' else 'rb'
                L.append((k, w))
        rows.append(('cell', e, L))
    H = 52 + 36 + sum((len(r[2])*lh + 16) for r in rows) + 20
    img = Image.new('RGB', (width, H), BG); d = ImageDraw.Draw(img)
    d.rectangle([0,0,width,40], fill=BAR)
    for i,c in enumerate(['#ff5f57','#febc2e','#28c840']): d.ellipse([16+i*22,13,30+i*22,27], fill=c)
    d.text((100, 10), sc.title, font=ft, fill=FG)
    y = 52
    for i,(k,lab) in enumerate(cols):
        x = xs[i]
        d.rectangle([x, y, x+colws[i]-8, y+28], fill=BAR); d.text((x+10, y+5), lab, font=fb, fill=FG)
    y += 36
    for kind, e, L in rows:
        d.line([gut-6, y-4, width-pad, y-4], fill=GRID)
        d.text((14, y), f"t{e['step']}", font=fb, fill=DIM)
        if kind == 'note':
            for j,l in enumerate(L): d.text((gut+pad, y+j*lh), l, font=f, fill=DIM)
        else:
            ci = [k for k,_ in cols].index(e['sess']); x = xs[ci] + 10
            for j,(k,l) in enumerate(L):
                col = {'sql':SQL,'out':FG,'err':ERR,'wait':WAIT,'ok':OK,'rb':RB}[k]
                d.text((x, y+j*lh), l, font=fb if k in ('sql','ok','rb') else f, fill=col)
        y += len(L)*lh + 16
    img.save(path)
