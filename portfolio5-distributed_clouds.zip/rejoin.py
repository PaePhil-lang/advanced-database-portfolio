import json, subprocess, time
from tx import Scenario, render
B='/usr/lib/postgresql/16/bin'; D='/tmp/p5'
def sh(cmd):
    r = subprocess.run(['bash','-c',cmd], capture_output=True, text=True); o = (r.stdout + r.stderr).rstrip('\n')
    return o.split('\n') if o else []
def q(port, sql): return sh(f"su postgres -c \"psql -h {D} -p {port} -d idsdist -X -P pager=off -c \\\"{sql}\\\"\"")
fo = json.load(open('failover.json'))
sc = Scenario('A1 Failover: primary crash, promotion, client reconnect, old primary rejoins', {}); sc.prompts = {'O':'$ ','N':'new_primary=# '}
def add(k, cmd, out): sc.step += 1; sc.log.append(dict(step=sc.step, sess=k, sql=cmd, out=out, state='error' if any('ERROR' in l for l in out) else 'ok'))
acked = [l for l in fo['log'] if l['ok']]; crash = fo['events'][0][0]
before = [l for l in acked if l['t'] < crash]; after = [l for l in acked if l['t'] > crash]; fails = [l for l in fo['log'] if not l['ok']]
lines = [f"t={l['t']:>5.2f}s  {'OK  ' if l['ok'] else 'FAIL'}  " + l['out'].replace('\nINSERT 0 1','').replace('|', ' on ') for l in before[-2:]]
lines += [f"t={fails[0]['t']:>5.2f}s  FAIL  connection refused: primary :5501 is down", f"   ... {len(fails)} failed attempts in total, retried every 0.1 s ...", f"t={fails[-1]['t']:>5.2f}s  FAIL  no read-write server among 5501, 5502"]
lines += [f"t={l['t']:>5.2f}s  {'OK  ' if l['ok'] else 'FAIL'}  " + l['out'].replace('\nINSERT 0 1','').replace('|', ' on ') for l in after[:2]]
add('O', "# client loop: INSERT a heartbeat every 0.1 s using\n# \"host=... port=5501,5502 target_session_attrs=read-write\"", [])
for t, ev in fo['events'][:2]: add('O', f"{ev}    (t={t}s)", [])
add('O', "# client log around the failover", lines)
add('N', "SELECT pg_is_in_recovery() AS standby, count(*) AS rows_kept, max(id)\nFROM heartbeat;", q(5502, "SELECT pg_is_in_recovery() AS standby, count(*) AS rows_kept, max(id) FROM heartbeat;"))
add('N', "SELECT pg_create_physical_replication_slot('slot_5503'),\n       pg_create_physical_replication_slot('slot_5501');", q(5502, "SELECT pg_create_physical_replication_slot('slot_5503'), pg_create_physical_replication_slot('slot_5501');"))
add('O', "psql -p 5503 -c \"ALTER SYSTEM SET primary_conninfo = 'port=5502 application_name=standby_5503'\"\npsql -p 5503 -c 'SELECT pg_reload_conf()'    # standby 3 follows the new primary",
    q(5503, "ALTER SYSTEM SET primary_conninfo = 'host=/tmp/p5 port=5502 user=postgres application_name=standby_5503'") + q(5503, "SELECT pg_reload_conf()")[2:3])
out = sh(f"su postgres -c \"{B}/pg_rewind --target-pgdata={D}/n5501 --source-server='host={D} port=5502 user=postgres dbname=postgres' --progress\" 2>&1 | tail -4")
add('O', "pg_rewind --target-pgdata=n5501 --source-server='port=5502'    # old primary", out)
sh(f"touch {D}/n5501/standby.signal; chown postgres {D}/n5501/standby.signal")
sh(f"sed -i \"s/^port = 5502/port = 5501/; s/^cluster_name = 'standby_5502'/cluster_name = 'standby_5501'/\" {D}/n5501/postgresql.conf")
open(f'{D}/n5501/postgresql.auto.conf','w').write(f"primary_conninfo = 'host={D} port=5502 user=postgres application_name=standby_5501'\nprimary_slot_name = 'slot_5501'\n")
sh(f"chown postgres {D}/n5501/postgresql.auto.conf")
out = sh(f"su postgres -c '{B}/pg_ctl -D {D}/n5501 -l {D}/n5501.log start -w'")
add('O', "# pg_rewind copied 5502's config: set port 5501 again, add standby.signal,\n# point primary_conninfo at 5502 with slot_5501\npg_ctl -D n5501 start    # old primary rejoins as a standby", out)
time.sleep(2)
add('N', "SELECT application_name, state, sync_state, replay_lsn\nFROM pg_stat_replication ORDER BY 1;", q(5502, "SELECT application_name, state, sync_state, replay_lsn FROM pg_stat_replication ORDER BY 1;"))
add('N', "SELECT pg_walfile_name(pg_current_wal_lsn()) AS wal_file;  -- first 8 digits = timeline", q(5502, "SELECT pg_walfile_name(pg_current_wal_lsn()) AS wal_file;"))
render(sc, 'img/a1_failover.png', [('O','Shell (operator) and client log'), ('N','New primary :5502')])
open('img/a1_failover.txt','w').write(sc.text()); print(sc.text())
