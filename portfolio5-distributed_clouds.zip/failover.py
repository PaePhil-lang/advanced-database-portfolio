import subprocess, threading, time, json
B='/usr/lib/postgresql/16/bin'; D='/tmp/p5'
DSN = f"host={D},{D} port=5501,5502 dbname=idsdist target_session_attrs=read-write connect_timeout=1"
log = []; stop = False; T0 = time.time()
def writer():
    n = 0
    while not stop:
        n += 1; t = time.time() - T0
        r = subprocess.run(['su','postgres','-c',f"psql \"{DSN}\" -Atc \"INSERT INTO heartbeat (desk) VALUES ('front-desk-1') RETURNING id, current_setting('cluster_name')\""], capture_output=True, text=True)
        ok = r.returncode == 0
        log.append(dict(t=round(t,2), ok=ok, out=(r.stdout.strip() or r.stderr.strip().split('\n')[0])[:90]))
        time.sleep(0.1)
th = threading.Thread(target=writer); th.start()
events = []
time.sleep(3)
events.append((round(time.time()-T0,2), 'pg_ctl -D n5501 stop -m immediate   # primary crashes'))
subprocess.run(['su','postgres','-c',f'{B}/pg_ctl -D {D}/n5501 stop -m immediate'], capture_output=True)
time.sleep(3)   # health check: 3 missed 1-second probes
events.append((round(time.time()-T0,2), 'pg_ctl -D n5502 promote   # after 3 failed health checks'))
r = subprocess.run(['su','postgres','-c',f'{B}/pg_ctl -D {D}/n5502 promote -w'], capture_output=True, text=True)
events.append((round(time.time()-T0,2), 'promote returned: ' + r.stdout.strip().split('\n')[-1]))
time.sleep(4); stop = True; th.join()
json.dump(dict(log=log, events=events), open('failover.json','w'), indent=1)
acked = [l for l in log if l['ok']]
before = [l for l in acked if l['t'] < events[0][0]]; after = [l for l in acked if l['t'] > events[0][0]]
print('writes attempted', len(log), 'acked', len(acked), 'failed', len(log)-len(acked))
print('last ack before crash', before[-1]); print('first ack after', after[0])
for e in events: print(e)
for l in log:
    if not l['ok']: print('FAIL', l); break
