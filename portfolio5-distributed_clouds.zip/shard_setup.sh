P="su postgres -c"
for pair in "5511 1" "5512 2"; do set -- $pair
$P "psql -h /tmp/p5 -p $1 -qc 'DROP DATABASE IF EXISTS shard' -c 'CREATE DATABASE shard'"
$P "psql -h /tmp/p5 -p $1 -d shard -q" <<SQL
CREATE EXTENSION btree_gist;
CREATE TABLE appointment_shard (
  appointment_id bigint PRIMARY KEY, patient_id bigint NOT NULL, dentist_id int NOT NULL,
  branch_id smallint NOT NULL CHECK (branch_id = $2),
  start_at timestamptz NOT NULL, end_at timestamptz NOT NULL, status text NOT NULL, fee_total numeric(12,2) NOT NULL,
  EXCLUDE USING gist (dentist_id WITH =, tstzrange(start_at, end_at) WITH &&) WHERE (status NOT IN ('CANCELLED','NO_SHOW')));
CREATE INDEX ON appointment_shard (start_at);
SQL
done
$P "psql -h /tmp/p5 -p 5502 -d idsdist -q" <<'SQL'
CREATE EXTENSION IF NOT EXISTS postgres_fdw;
CREATE SERVER shard_ceddi FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host '/tmp/p5', port '5511', dbname 'shard', batch_size '1000');
CREATE SERVER shard_baze  FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host '/tmp/p5', port '5512', dbname 'shard', batch_size '1000');
CREATE USER MAPPING FOR postgres SERVER shard_ceddi OPTIONS (user 'postgres');
CREATE USER MAPPING FOR postgres SERVER shard_baze  OPTIONS (user 'postgres');
CREATE TABLE appt_global (
  appointment_id bigint, patient_id bigint, dentist_id int, branch_id smallint,
  start_at timestamptz, end_at timestamptz, status text, fee_total numeric(12,2)
) PARTITION BY LIST (branch_id);
CREATE FOREIGN TABLE appt_ceddi PARTITION OF appt_global FOR VALUES IN (1)
  SERVER shard_ceddi OPTIONS (table_name 'appointment_shard');
CREATE FOREIGN TABLE appt_baze PARTITION OF appt_global FOR VALUES IN (2)
  SERVER shard_baze OPTIONS (table_name 'appointment_shard');
SQL
time $P "psql -h /tmp/p5 -p 5502 -d idsdist -qc \"\\copy appt_global FROM '/tmp/p5/appts.csv' CSV\""
for p in 5511 5512; do $P "psql -h /tmp/p5 -p $p -d shard -qc 'ANALYZE'"; done
