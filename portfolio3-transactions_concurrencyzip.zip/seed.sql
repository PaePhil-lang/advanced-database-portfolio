INSERT INTO branch (branch_name, street_address) VALUES
 ('Ceddi Plaza','Plot 264 Tafawa Balewa Way, Central Area'),
 ('Baze University Hospital','Plot 686 Jabi Airport Road bypass');
INSERT INTO branch_phone VALUES ('09087812031',1,'Main'),('08024046026',2,'Main');
INSERT INTO branch_hours SELECT b, d, '09:00', '19:00' FROM generate_series(1,2) b, generate_series(1,5) d;
INSERT INTO branch_hours SELECT b, 6, '09:00', '16:00' FROM generate_series(1,2) b;
INSERT INTO specialty (specialty_name) VALUES ('General dentistry'),('Orthodontics'),('Oral and maxillofacial surgery'),('Periodontology'),('Paediatric dentistry');
INSERT INTO staff (first_name,last_name,job_role,email,home_branch_id) VALUES
 ('Funke','Bello','DENTIST','f.bello@ids.test',1),('Kunle','Ade','DENTIST','k.ade@ids.test',2),
 ('Ifeoma','Eze','DENTIST','i.eze@ids.test',1),('Ngozi','Okafor','RECEPTION','n.okafor@ids.test',1),
 ('Tunde','Lawal','ACCOUNTS','t.lawal@ids.test',1);
INSERT INTO dentist VALUES (1,'MDCN/R/1234',1,false),(2,'MDCN/R/5678',2,true),(3,'MDCN/R/9012',1,false);
INSERT INTO dentist_session (dentist_id,branch_id,day_of_week,start_time,end_time)
 SELECT d, 1, w, '09:00', CASE WHEN w=6 THEN '16:00'::time ELSE '17:00'::time END FROM (VALUES (1),(3)) x(d), generate_series(1,6) w;
INSERT INTO dentist_session (dentist_id,branch_id,day_of_week,start_time,end_time) VALUES (2,2,4,'10:00','14:00');
INSERT INTO service_category (category_name) VALUES ('Consultation and diagnosis'),('Restorative'),('Orthodontic');
INSERT INTO service VALUES ('GEN-EXM',1,'Examination',10000,20,NULL),('RES-FIL',2,'Composite filling',25000,40,NULL),('ORT-BRC',3,'Fixed braces fitting',450000,90,2);
INSERT INTO patient (hospital_no,first_name,last_name,date_of_birth,sex,phone,registered_branch_id)
 VALUES ('IDS-000100','Chidi','Obi','1985-01-01','M','+2348035550000',1);
INSERT INTO patient (hospital_no,first_name,last_name,date_of_birth,sex,phone,registered_branch_id,guardian_id)
 VALUES ('IDS-000231','Amaka','Obi','2016-03-12','F','+2348031112233',1,1);
INSERT INTO patient (hospital_no,first_name,last_name,date_of_birth,sex,phone,registered_branch_id)
 VALUES ('IDS-000598','Musa','Ibrahim','1988-07-04','M','+2348129990011',1);
-- Thursday 12 Nov 2026: Amaka's completed visit, billed
INSERT INTO appointment (patient_id,dentist_id,branch_id,start_at,end_at,appt_type,booking_channel)
 VALUES (2,1,1,'2026-11-12 10:00+01','2026-11-12 10:40+01','PLANNED','ONLINE');
INSERT INTO treatment (appointment_id,service_code,fee_charged) VALUES (1,'GEN-EXM',10000);
INSERT INTO treatment (appointment_id,service_code,tooth_fdi,surface,fee_charged) VALUES (1,'RES-FIL',75,'O',22500);
UPDATE appointment SET status='COMPLETED' WHERE appointment_id=1;
INSERT INTO invoice (invoice_no,appointment_id) VALUES ('INV-2026-000412',1);
