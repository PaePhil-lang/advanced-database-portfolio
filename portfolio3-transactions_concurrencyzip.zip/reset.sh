su postgres -c "psql -h /tmp/pg -q -c 'DROP DATABASE IF EXISTS idstx' -c 'CREATE DATABASE idstx'" >/dev/null
su postgres -c "psql -h /tmp/pg -d idstx -q -v ON_ERROR_STOP=1 -f /home/claude/ideal_dental_schema.sql -f /home/claude/p3/seed.sql" >/dev/null
