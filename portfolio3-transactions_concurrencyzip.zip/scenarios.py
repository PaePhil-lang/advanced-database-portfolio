import subprocess, json, sys
from tx import Sess, Scenario, render
def reset(extra=''):
    subprocess.run(['bash','/home/claude/p3/reset.sh'], check=True)
    if extra:
        r = subprocess.run(['su','postgres','-c','psql -h /tmp/pg -d idstx -q -v ON_ERROR_STOP=1'], input=extra, text=True, capture_output=True)
        if r.returncode: raise SystemExit(r.stderr)
def go(key, title, cols, body, extra=''):
    reset(extra)
    ss = {k: Sess(k, lab) for k, lab in cols}
    sc = Scenario(title, ss); body(sc)
    for s in ss.values(): s.close()
    render(sc, f'img/{key}.png', cols); open(f'img/{key}.txt','w').write(sc.text()); print(sc.text()); print()
A = ('A','Session A: Reception desk 1'); B = ('B','Session B: Reception desk 2')
ACC = ('A','Session A: Accounts till 1'); ACC2 = ('B','Session B: Accounts till 2')
MGR1 = ('A','Session A: Branch manager'); MGR2 = ('B','Session B: Deputy manager')
MON = ('C','Session C: DBA monitor')
TWO_APPTS = """INSERT INTO appointment (patient_id,dentist_id,branch_id,start_at,end_at,appt_type,booking_channel)
 VALUES (1,1,1,'2026-11-16 09:00+01','2026-11-16 09:40+01','PLANNED','ONLINE'),
        (3,3,1,'2026-11-16 09:00+01','2026-11-16 09:40+01','PLANNED','PHONE');"""
ARRIVED = """INSERT INTO appointment (patient_id,dentist_id,branch_id,start_at,end_at,appt_type,booking_channel,status)
 VALUES (3,3,1,'2026-11-12 11:00+01','2026-11-12 11:40+01','PLANNED','PHONE','ARRIVED');"""
NAIVE = "CREATE TABLE appointment_naive (LIKE appointment INCLUDING DEFAULTS INCLUDING IDENTITY);"
BAL = "SELECT amount_due, amount_paid, balance, payment_status\nFROM v_invoice_balance WHERE invoice_id = 1;"

def e1(s):
    s.run('A', "BEGIN;")
    s.run('A', "INSERT INTO appointment (patient_id, dentist_id, branch_id,\n  start_at, end_at, appt_type, booking_channel)\nVALUES (3, 3, 1, '2026-11-14 11:00+01', '2026-11-14 11:40+01', 'PLANNED', 'PHONE')\nRETURNING appointment_id, status;")
    s.run('A', "INSERT INTO reminder (appointment_id, channel, send_at)\nSELECT 2, c, TIMESTAMPTZ '2026-11-14 11:00+01' - l\nFROM (VALUES ('SMS', interval '24 hours'), ('EMAIL', interval '48 hours')) v(c, l);")
    s.run('B', "SELECT appointment_id, patient_id, status FROM appointment WHERE patient_id = 3;")
    s.run('A', "COMMIT;")
    s.run('B', "SELECT appointment_id, patient_id, status FROM appointment WHERE patient_id = 3;")
    s.run('B', "SELECT channel, send_at, delivery_status FROM reminder WHERE appointment_id = 2;")
def e2a(s):
    s.run('A', "BEGIN;")
    s.run('A', "INSERT INTO payment (invoice_id, amount, method, reference, received_by)\nVALUES (1, 15000, 'POS', 'POS-7781', 5) RETURNING payment_id, amount;")
    s.run('A', "INSERT INTO payment (invoice_id, amount, method, reference, received_by)\nVALUES (1, 20000, 'TRANSFER', 'TRF-5530', 5);")
    s.run('A', BAL)
    s.run('A', "ROLLBACK;")
    s.run('A', BAL)
def e2b(s):
    s.run('A', "BEGIN;")
    s.run('A', "INSERT INTO treatment (appointment_id, service_code, fee_charged) VALUES (2, 'GEN-EXM', 10000);")
    s.run('A', "SAVEPOINT before_braces;")
    s.run('A', "INSERT INTO treatment (appointment_id, service_code, fee_charged) VALUES (2, 'ORT-BRC', 450000);")
    s.run('A', "ROLLBACK TO SAVEPOINT before_braces;")
    s.run('A', "INSERT INTO treatment (appointment_id, service_code, tooth_fdi, surface, fee_charged)\nVALUES (2, 'RES-FIL', 36, 'MO', 25000);")
    s.run('A', "COMMIT;")
    s.run('A', "SELECT treatment_id, service_code, tooth_fdi, fee_charged\nFROM treatment WHERE appointment_id = 2;")
def e3a(s):
    s.run('A', "BEGIN ISOLATION LEVEL READ COMMITTED;")
    s.run('A', BAL)
    s.run('B', "INSERT INTO payment (invoice_id, amount, method, reference, received_by)\nVALUES (1, 15000, 'POS', 'POS-7781', 5);")
    s.run('A', BAL)
    s.run('A', "COMMIT;")
def e3b(s):
    s.run('A', "BEGIN ISOLATION LEVEL REPEATABLE READ;")
    s.run('A', BAL)
    s.run('B', "INSERT INTO payment (invoice_id, amount, method, reference, received_by)\nVALUES (1, 15000, 'POS', 'POS-7781', 5);")
    s.run('A', BAL)
    s.run('B', "UPDATE invoice SET discount = 2000 WHERE invoice_id = 1;")
    s.run('A', "UPDATE invoice SET discount = 5000 WHERE invoice_id = 1;")
    s.run('A', "ROLLBACK;")
    s.run('A', BAL)
CNT = "SELECT count(*) AS saturday_dentists FROM dentist_session\nWHERE branch_id = 1 AND day_of_week = 6;"
def skew(level):
    def f(s):
        s.run('A', f"BEGIN ISOLATION LEVEL {level};"); s.run('B', f"BEGIN ISOLATION LEVEL {level};")
        s.run('A', CNT); s.run('B', CNT)
        s.run('A', "DELETE FROM dentist_session\nWHERE dentist_id = 1 AND branch_id = 1 AND day_of_week = 6;")
        s.run('B', "DELETE FROM dentist_session\nWHERE dentist_id = 3 AND branch_id = 1 AND day_of_week = 6;")
        s.run('A', "COMMIT;"); s.run('B', "COMMIT;")
        if level == 'SERIALIZABLE':
            s.note("Application retry: Session B's transaction failed with SQLSTATE 40001, so the app starts it again from the top.")
            s.run('B', "BEGIN ISOLATION LEVEL SERIALIZABLE;"); s.run('B', CNT)
            s.note("The check now finds only 1 dentist rostered, so the app refuses to remove the last one and rolls back.")
            s.run('B', "ROLLBACK;")
        s.run('A', CNT)
    return f
def e4a(s):
    s.run('A', "BEGIN;"); s.run('B', "BEGIN;")
    s.run('A', "SELECT discount FROM invoice WHERE invoice_id = 1;")
    s.run('B', "SELECT discount FROM invoice WHERE invoice_id = 1;")
    s.note("Each desk adds a N5,000 goodwill discount to the value it read (0 + 5000) and writes the result back.")
    s.run('A', "UPDATE invoice SET discount = 5000 WHERE invoice_id = 1;")
    s.run('B', "UPDATE invoice SET discount = 5000 WHERE invoice_id = 1;")
    s.run('A', "COMMIT;"); s.poll('B'); s.run('B', "COMMIT;")
    s.run('A', "SELECT discount FROM invoice WHERE invoice_id = 1;")
OVL = "SELECT count(*) AS clashes FROM appointment_naive\nWHERE dentist_id = 3 AND tstzrange(start_at, end_at)\n   && tstzrange('2026-11-14 12:00+01', '2026-11-14 12:40+01');"
def e4b(s):
    s.run('A', "BEGIN;"); s.run('B', "BEGIN;")
    s.run('A', OVL); s.run('B', OVL)
    s.run('A', "INSERT INTO appointment_naive (patient_id, dentist_id, branch_id,\n  start_at, end_at, appt_type, booking_channel, status)\nVALUES (1, 3, 1, '2026-11-14 12:00+01', '2026-11-14 12:40+01', 'PLANNED', 'ONLINE', 'BOOKED');")
    s.run('B', "INSERT INTO appointment_naive (patient_id, dentist_id, branch_id,\n  start_at, end_at, appt_type, booking_channel, status)\nVALUES (3, 3, 1, '2026-11-14 12:20+01', '2026-11-14 13:00+01', 'PLANNED', 'PHONE', 'BOOKED');")
    s.run('A', "COMMIT;"); s.run('B', "COMMIT;")
    s.run('A', "SELECT appointment_id, patient_id, dentist_id,\n       start_at::time AS starts, end_at::time AS ends\nFROM appointment_naive;")
def e4c(s):
    s.run('A', "BEGIN;"); s.run('B', "BEGIN;")
    s.run('A', "UPDATE appointment SET status = 'CONFIRMED' WHERE appointment_id = 2;")
    s.run('B', "UPDATE appointment SET status = 'CONFIRMED' WHERE appointment_id = 3;")
    s.run('A', "UPDATE appointment SET status = 'CONFIRMED' WHERE appointment_id = 3;")
    s.run('B', "UPDATE appointment SET status = 'CONFIRMED' WHERE appointment_id = 2;", wait=4)
    s.poll('A'); s.run('B', "ROLLBACK;"); s.run('A', "COMMIT;")
    s.run('A', "SELECT appointment_id, status FROM appointment\nWHERE appointment_id IN (2, 3) ORDER BY 1;")
def e5a(s):
    s.run('A', "BEGIN;"); s.run('B', "BEGIN;")
    s.run('A', "SELECT discount FROM invoice WHERE invoice_id = 1 FOR UPDATE;")
    s.run('B', "SELECT discount FROM invoice WHERE invoice_id = 1 FOR UPDATE;")
    s.run('A', "UPDATE invoice SET discount = 5000 WHERE invoice_id = 1;")
    s.run('A', "COMMIT;"); s.poll('B')
    s.run('B', "UPDATE invoice SET discount = 10000 WHERE invoice_id = 1;")
    s.run('B', "COMMIT;")
    s.run('A', "SELECT discount FROM invoice WHERE invoice_id = 1;")
def e5b(s):
    s.run('A', "BEGIN;")
    s.run('A', "UPDATE invoice SET discount = discount + 5000 WHERE invoice_id = 1;")
    s.run('B', "UPDATE invoice SET discount = discount + 5000 WHERE invoice_id = 1;")
    s.run('A', "COMMIT;"); s.poll('B')
    s.run('A', "SELECT discount FROM invoice WHERE invoice_id = 1;")
def e5c(s):
    s.run('A', "SELECT discount, xmin AS row_version FROM invoice WHERE invoice_id = 1;")
    s.run('B', "SELECT discount, xmin AS row_version FROM invoice WHERE invoice_id = 1;")
    s.run('A', "UPDATE invoice SET discount = 5000\nWHERE invoice_id = 1 AND discount = 0;")
    s.run('B', "UPDATE invoice SET discount = 5000\nWHERE invoice_id = 1 AND discount = 0;")
    s.note("UPDATE 0 tells the app its copy is stale. It re-reads the row and re-applies the change to the current value.")
    s.run('B', "SELECT discount, xmin AS row_version FROM invoice WHERE invoice_id = 1;")
    s.run('B', "UPDATE invoice SET discount = 10000\nWHERE invoice_id = 1 AND discount = 5000;")
MONQ = "SELECT pid, state, wait_event_type AS wait,\n       pg_blocking_pids(pid) AS blocked_by\nFROM pg_stat_activity\nWHERE datname = 'idstx' AND pid <> pg_backend_pid()\nORDER BY pid;"
def e5d(s):
    s.run('A', "BEGIN;"); s.run('B', "BEGIN;")
    s.run('A', "SELECT pg_backend_pid();"); s.run('B', "SELECT pg_backend_pid();")
    s.run('A', "INSERT INTO appointment (patient_id, dentist_id, branch_id,\n  start_at, end_at, appt_type, booking_channel)\nVALUES (1, 3, 1, '2026-11-14 12:00+01', '2026-11-14 12:40+01', 'PLANNED', 'ONLINE');")
    s.run('B', "INSERT INTO appointment (patient_id, dentist_id, branch_id,\n  start_at, end_at, appt_type, booking_channel)\nVALUES (3, 3, 1, '2026-11-14 12:20+01', '2026-11-14 13:00+01', 'PLANNED', 'PHONE');")
    s.run('C', MONQ)
    s.run('A', "COMMIT;"); s.poll('B'); s.run('B', "ROLLBACK;")
    s.run('A', "SELECT appointment_id, patient_id, start_at::time AS starts, end_at::time AS ends\nFROM appointment WHERE dentist_id = 3;")
def e5e(s):
    s.run('A', "BEGIN;")
    s.run('A', "INSERT INTO payment (invoice_id, amount, method, reference, received_by)\nVALUES (1, 20000, 'POS', 'POS-9001', 5);")
    s.run('B', "INSERT INTO payment (invoice_id, amount, method, reference, received_by)\nVALUES (1, 20000, 'TRANSFER', 'TRF-9002', 5);")
    s.run('A', "COMMIT;"); s.poll('B')
    s.run('A', BAL)

ALL = {
 'e1_commit': ('E1 Commit: booking + reminders in one transaction', [A,B], e1, ''),
 'e2a_rollback': ('E2a Rollback: trigger error aborts the whole payment transaction', [ACC], e2a, ''),
 'e2b_savepoint': ('E2b Savepoint: roll back one failed procedure, keep the rest', [('A','Session A: Dr Eze, chair-side')], e2b, ARRIVED),
 'e3a_read_committed': ('E3a READ COMMITTED: non-repeatable read', [ACC,ACC2], e3a, ''),
 'e3b_repeatable_read': ('E3b REPEATABLE READ: stable snapshot + update conflict', [ACC,ACC2], e3b, ''),
 'e3c_write_skew_rr': ('E3c Write skew under REPEATABLE READ: Saturday cover lost', [MGR1,MGR2], skew('REPEATABLE READ'), ''),
 'e3d_serializable': ('E3d SERIALIZABLE: write skew detected and retried', [MGR1,MGR2], skew('SERIALIZABLE'), ''),
 'e4a_lost_update': ('E4a Lost update: two desks apply a discount', [A,B], e4a, ''),
 'e4b_double_booking': ('E4b Double-booking race on a table without the exclusion constraint', [A,B], e4b, NAIVE),
 'e4c_deadlock': ('E4c Deadlock: two desks confirm two appointments in opposite order', [A,B], e4c, TWO_APPTS),
 'e5a_for_update': ('E5a Pessimistic lock: SELECT ... FOR UPDATE', [A,B], e5a, ''),
 'e5b_atomic_update': ('E5b Atomic update: discount = discount + 5000', [A,B], e5b, ''),
 'e5c_optimistic': ('E5c Optimistic check: UPDATE ... WHERE value unchanged', [A,B], e5c, ''),
 'e5d_exclusion': ('E5d Exclusion constraint stops the double-booking race', [A,B,MON], e5d, ''),
 'e5e_payment_cap': ('E5e Payment-cap trigger serialises two tills with a row lock', [ACC,ACC2], e5e, ''),
}
for k in (sys.argv[1:] or ALL):
    t, cols, body, extra = ALL[k]; go(k, t, cols, body, extra)
