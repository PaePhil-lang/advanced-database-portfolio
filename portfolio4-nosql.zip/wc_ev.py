from ev import *
t = T('Wide-column model: Cassandra partition design, emulated with PostgreSQL hash partitions', 'ids2=# ', 'Session: widecol schema (partition key = branch_id, day; clustering = start_at)')
q = [
 "SELECT tableoid::regclass AS partition, count(*) AS rows\nFROM widecol.appointments_by_branch_day\nGROUP BY 1 ORDER BY 1 LIMIT 6;",
 "SELECT start_at::time AS starts, hospital_no, patient_name, dentist, status\nFROM widecol.appointments_by_branch_day\nWHERE branch_id = 1 AND day = '2026-11-12'\nORDER BY start_at LIMIT 6;",
 "EXPLAIN (ANALYZE, COSTS OFF, SUMMARY ON)\nSELECT * FROM widecol.appointments_by_branch_day\nWHERE branch_id = 1 AND day = '2026-11-12'\nORDER BY start_at;",
 "EXPLAIN (COSTS OFF)\nSELECT * FROM widecol.appointments_by_branch_day\nWHERE hospital_no = 'IDS-039180';",
]
for sql in q:
    out = psql(sql)
    if 'hospital_no = ' in sql and 'EXPLAIN' in sql: out = out[:9] + ['         ... 14 more Parallel Seq Scan nodes: all 16 partitions are scanned', out[-1]]
    t.add(sql, out, any(l.startswith('ERROR') for l in out))
t.save('wc_evidence'); print(open('out/wc_evidence.txt').read())
