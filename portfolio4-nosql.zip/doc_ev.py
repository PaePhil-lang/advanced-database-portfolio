from ev import *
psql("DROP INDEX IF EXISTS docstore.ix_patients_doc; UPDATE docstore.patients SET doc = (doc - 'ortho') || jsonb_build_object('medical_alerts', '[\"Asthma\"]'::jsonb) WHERE _id = 'IDS-039180';")
t = T('Document model: patients collection (PostgreSQL 16 JSONB as document store)', 'ids2=# ', 'Session: document store, collection docstore.patients')
q = [
 ("SELECT count(*) AS documents,\n       pg_size_pretty(pg_total_relation_size('docstore.patients')) AS size\nFROM docstore.patients;", None),
 ("SELECT jsonb_pretty(doc) FROM docstore.patients WHERE _id = 'IDS-039180';", None),
 ("CREATE INDEX ix_patients_doc ON docstore.patients USING gin (doc jsonb_path_ops);", None),
 ("SELECT count(*) AS latex_allergy_ceddi\nFROM docstore.patients\nWHERE doc @> '{\"home_branch\": \"Ceddi Plaza\",\n               \"medical_alerts\": [\"Latex allergy\"]}';", None),
 ("EXPLAIN (ANALYZE, COSTS OFF, SUMMARY ON)\nSELECT _id FROM docstore.patients\nWHERE doc @> '{\"home_branch\": \"Ceddi Plaza\", \"medical_alerts\": [\"Latex allergy\"]}';", None),
 ("SELECT count(*) AS root_canal_on_36\nFROM docstore.patients\nWHERE doc @? '$.dental_chart.\"36\"[*] ? (@.code == \"RES-RCT\")';", None),
 ("UPDATE docstore.patients\nSET doc = jsonb_set(doc, '{medical_alerts}',\n          coalesce(doc->'medical_alerts', '[]') || '\"Penicillin allergy\"')\nWHERE _id = 'IDS-039180'\nRETURNING doc->'medical_alerts' AS medical_alerts;", None),
 ("UPDATE docstore.patients\nSET doc = doc || '{\"ortho\": {\"appliance\": \"clear aligners\", \"tray\": 7, \"of\": 24}}'\nWHERE _id = 'IDS-039180'\nRETURNING doc->'ortho' AS ortho, doc->>'schema_version' AS v;", None),
]
for sql, _ in q:
    out = psql(sql)
    if 'jsonb_pretty' in sql: out = [l.rstrip().rstrip('+').rstrip() for l in out]
    t.add(sql, out, any(l.startswith('ERROR') for l in out))
t.save('doc_evidence')
print(open('out/doc_evidence.txt').read())
