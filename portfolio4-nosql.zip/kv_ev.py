from ev import *
import time, subprocess
t = T('Key-value model: Redis 7.0 for sessions, slot holds, cache, queue and counters', '127.0.0.1:6379> ', 'Session: redis-cli')
cmds = [
 ['HSET','session:7f3c9a','staff_id','4','name','Ngozi Okafor','role','RECEPTION','branch','1'],
 ['EXPIRE','session:7f3c9a','1800'],
 ['HGETALL','session:7f3c9a'],
 ['TTL','session:7f3c9a'],
 '#Online booking: the website holds Dr Eze\'s Saturday 12:00 slot for 5 minutes while the patient pays; desk 2 then tries the same slot.',
 ['SET','hold:dentist:3:2026-11-14T12:00','web-checkout-91c2','NX','EX','300'],
 ['SET','hold:dentist:3:2026-11-14T12:00','desk-2','NX','EX','300'],
 ['GET','hold:dentist:3:2026-11-14T12:00'],
 ['TTL','hold:dentist:3:2026-11-14T12:00'],
 ['SET','cache:patient:IDS-039180','{"name":"Zainab Garba","alerts":["Asthma"],"guardian":"Yakubu Chukwu","balance":0}','EX','600'],
 ['GET','cache:patient:IDS-039180'],
 '#Reminder queue: score = send time (Unix seconds). The dispatcher runs at 11:00 on 13 Nov and takes everything due.',
 ['ZADD','reminders:due','1794556800','rem:521087:SMS','1794556800','rem:521127:SMS','1794567600','rem:628033:EMAIL','1794643200','rem:628039:SMS'],
 ['ZRANGEBYSCORE','reminders:due','-inf','1794564000','WITHSCORES'],
 ['ZPOPMIN','reminders:due','2'],
 ['ZCARD','reminders:due'],
 ['INCR','stats:2026-11-13:branch:1:checkins'],
 ['INCR','stats:2026-11-13:branch:1:checkins'],
 ['INCRBY','stats:2026-11-13:branch:1:revenue_ngn','32500'],
 ['MGET','stats:2026-11-13:branch:1:checkins','stats:2026-11-13:branch:1:revenue_ngn'],
 '#OTP for the patient portal: at most 3 requests per phone number per 10 minutes.',
 ['INCR','otp:rate:+2349100039180'],
 ['EXPIRE','otp:rate:+2349100039180','600','NX'],
 ['INFO','keyspace'],
]
for c in cmds:
    if isinstance(c, str): t.note(c[1:]); continue
    out = redis(c)
    shown = ' '.join(x if (' ' not in x and x) else f'"{x}"' if '"' not in x else "'" + x + "'" for x in c)
    if c[0] in ('INFO',): out = [l for l in out if l.strip()]
    if c[0] in ('SET','GET') and out == ['']: out = ['(nil)']
    t.add(shown, out)
t.save('kv_evidence'); print(open('out/kv_evidence.txt').read())
