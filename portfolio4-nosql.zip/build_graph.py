
G = nx.MultiDiGraph()
for b, name in csv.reader(open('/tmp/g_branch.csv')): G.add_node(f'B{b}', label='Branch', name=name)
for h, name in csv.reader(open('/tmp/g_hmo.csv')): G.add_node(f'H{h}', label='HMO', name=name)
for d, name, spec, home, visiting in csv.reader(open('/tmp/g_dentists.csv')):
    G.add_node(f'D{d}', label='Dentist', name=name, visiting=visiting == 't')
    G.add_node(spec, label='Specialty', name=spec); G.add_edge(f'D{d}', spec, type='HAS_SPECIALTY')
for d, b in csv.reader(open('/tmp/g_works.csv')): G.add_edge(f'D{d}', f'B{b}', type='WORKS_AT')
for pid, hno, name, guardian, hmo in csv.reader(open('/tmp/g_patients.csv')):
    G.add_node(f'P{pid}', label='Patient', hospital_no=hno, name=name)
    if hmo: G.add_edge(f'P{pid}', f'H{hmo}', type='COVERED_BY')
    if guardian: G.add_edge(f'P{guardian}', f'P{pid}', type='GUARDIAN_OF')
for pid, d, n, last in csv.reader(open('/tmp/g_treated.csv')): G.add_edge(f'P{pid}', f'D{d}', type='TREATED_BY', visits=int(n), last=last)
for pid, ref, spec, day in csv.reader(open('/tmp/g_referrals.csv')): G.add_edge(f'D{ref}', f'D{spec}', type='REFERRED', patient=f'P{pid}', date=day)
