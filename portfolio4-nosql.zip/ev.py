import subprocess, sys, re
from tx import render
class T:  # one-session transcript
    def __init__(s, title, prompt, label): s.title, s.prompt, s.log, s.label = title, prompt, [], label
    def add(s, cmd, out, err=False):
        s.log.append(dict(step=len(s.log)+1, sess='A', sql=cmd, out=out, state='error' if err else 'ok'))
    def note(s, text): s.log.append(dict(step=len(s.log)+1, sess=None, sql=None, out=[text], state='note'))
    def save(s, key):
        render(s, f'out/{key}.png', [('A', s.label)])
        with open(f'out/{key}.txt','w') as f:
            for e in s.log:
                if e['sql']: f.write(f"{s.prompt}{e['sql']}\n")
                f.write('\n'.join(e['out'])+'\n')
def psql(sql, db='ids2'):
    r = subprocess.run(['su','postgres','-c',f'psql -h /tmp/pg -d {db} -X -P pager=off'], input=sql, capture_output=True, text=True)
    return [l for l in (r.stdout + r.stderr).rstrip('\n').split('\n')]
def redis(cmd):
    r = subprocess.run(['redis-cli','--no-raw'] + cmd, capture_output=True, text=True)
    return r.stdout.rstrip('\n').split('\n')
