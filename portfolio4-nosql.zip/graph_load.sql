\copy (SELECT p.patient_id, p.hospital_no, p.first_name||' '||p.last_name, p.guardian_id, p.hmo_id FROM patient p) TO '/tmp/g_patients.csv' CSV
\copy (SELECT d.staff_id, 'Dr '||s.first_name||' '||s.last_name, sp.specialty_name, s.home_branch_id, d.is_visiting FROM dentist d JOIN staff s USING (staff_id) JOIN specialty sp USING (specialty_id)) TO '/tmp/g_dentists.csv' CSV
\copy (SELECT patient_id, dentist_id, count(*), max((start_at AT TIME ZONE 'Africa/Lagos')::date) FROM appointment WHERE status='COMPLETED' GROUP BY 1,2) TO '/tmp/g_treated.csv' CSV
\copy (SELECT DISTINCT dentist_id, branch_id FROM dentist_session) TO '/tmp/g_works.csv' CSV
\copy (SELECT hmo_id, hmo_name FROM hmo_provider) TO '/tmp/g_hmo.csv' CSV
\copy (SELECT branch_id, branch_name FROM branch) TO '/tmp/g_branch.csv' CSV
\copy (SELECT s.patient_id, g.dentist_id AS referrer, s.dentist_id AS specialist, (s.start_at AT TIME ZONE 'Africa/Lagos')::date FROM appointment s JOIN dentist ds ON ds.staff_id = s.dentist_id AND ds.is_visiting JOIN LATERAL (SELECT a.dentist_id FROM appointment a JOIN dentist d ON d.staff_id=a.dentist_id AND NOT d.is_visiting WHERE a.patient_id = s.patient_id AND a.status='COMPLETED' AND a.start_at < s.start_at AND a.start_at >= s.start_at - interval '60 days' ORDER BY a.start_at DESC LIMIT 1) g ON true WHERE s.status='COMPLETED') TO '/tmp/g_referrals.csv' CSV
