import csv, io, contextlib, networkx as nx
from ev import T
t = T('Graph model: property graph in NetworkX 3.7 (Neo4j-style labels and relationships)', '>>> ', 'Session: Python 3, networkx')
ns = {'nx': nx, 'csv': csv}
setup = r'''
G = nx.MultiDiGraph()
for b, name in csv.reader(open('/tmp/g_branch.csv')): G.add_node(f'B{b}', label='Branch', name=name)
for h, name in csv.reader(open('/tmp/g_hmo.csv')): G.add_node(f'H{h}', label='HMO', name=name)
for d, name, spec, home, visiting in csv.reader(open('/tmp/g_dentists.csv')):
    G.add_node(f'D{d}', label='Dentist', name=name, visiting=visiting == 't')
    G.add_node(spec, label='Specialty', name=spec); G.add_edge(f'D{d}', spec, type='HAS_SPECIALTY')
for d, b in csv.reader(open('/tmp/g_works.csv')): G.add_edge(f'D{d}', f'B{b}', type='WORKS_AT')
for pid, hno, name, guardian, hmo in csv.reader(open('/tmp/g_patients.csv')):
    G.add_node(f'P{pid}', label='Patient', hospital_no=hno, name=name)
    if hmo: G.add_edge(f'P{pid}', f'H{hmo}', type='COVERED_BY')
    if guardian: G.add_edge(f'P{guardian}', f'P{pid}', type='GUARDIAN_OF')
for pid, d, n, last in csv.reader(open('/tmp/g_treated.csv')): G.add_edge(f'P{pid}', f'D{d}', type='TREATED_BY', visits=int(n), last=last)
for pid, ref, spec, day in csv.reader(open('/tmp/g_referrals.csv')): G.add_edge(f'D{ref}', f'D{spec}', type='REFERRED', patient=f'P{pid}', date=day)
'''
cmds = [
 ("# load nodes and relationships exported from the relational core\nexec(open('build_graph.py').read())\nprint(G.number_of_nodes(), 'nodes,', G.number_of_edges(), 'relationships')", setup),
 ("from collections import Counter\nprint(Counter(d['label'] for _, d in G.nodes(data=True)))\nprint(Counter(d['type'] for *_, d in G.edges(data=True)))", None),
 ("# Q1 referral network: which general dentist sends most patients to which specialist?\nref = Counter((G.nodes[u]['name'], G.nodes[v]['name'], list(G.successors(v))[0])\n              for u, v, d in G.edges(data=True) if d['type'] == 'REFERRED')\nfor (gp, sp, spec), n in ref.most_common(5): print(f'{n:>3}  {gp:<18} -> {sp:<18} ({spec})')", None),
 ("# Q2 specialists ranked by referrals received (weighted in-degree)\nindeg = Counter(v for u, v, d in G.edges(data=True) if d['type'] == 'REFERRED')\nfor v, n in indeg.most_common(): print(f\"{n:>4}  {G.nodes[v]['name']:<18} {list(G.successors(v))[0]}\")", None),
 ("# Q3 household: a guardian, their dependants, and every dentist who treats the household\ng = next(u for u, v, d in G.edges(data=True) if d['type'] == 'GUARDIAN_OF' and v == 'P39180')\nhouse = [g] + [v for _, v, d in G.out_edges(g, data=True) if d['type'] == 'GUARDIAN_OF']\nfor p in house:\n    docs = sorted({G.nodes[v]['name'] for _, v, d in G.out_edges(p, data=True) if d['type'] == 'TREATED_BY'})\n    print(G.nodes[p]['hospital_no'], G.nodes[p]['name'], '->', ', '.join(docs))", None),
 ("# Q4 patient journey: how did a referred patient reach Orthodontics?\n# ignore direct visits to specialists and other patients' referrals, then find the shortest path\np = next(d['patient'] for u, v, d in G.edges(data=True) if d['type'] == 'REFERRED' and list(G.successors(v))[0] == 'Orthodontics')\nH = nx.subgraph_view(G, filter_edge=lambda u, v, k: not (\n      (G[u][v][k]['type'] == 'TREATED_BY' and G.nodes[v]['visiting'])\n   or (G[u][v][k]['type'] == 'REFERRED' and G[u][v][k]['patient'] != p)))\npath = nx.shortest_path(H, p, 'Orthodontics')\nprint(' -> '.join(G.nodes[n].get('hospital_no') or G.nodes[n]['name'] for n in path))\nprint('relationships:', [next(d['type'] for d in H.get_edge_data(a, b).values()) for a, b in zip(path, path[1:])])", None),
]
for shown, real in cmds:
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        if real: exec(real, ns)
        exec(shown.replace("exec(open('build_graph.py').read())", ''), ns)
    t.add(shown, buf.getvalue().rstrip('\n').split('\n'))
open('build_graph.py','w').write(setup)
t.save('graph_evidence'); print(open('out/graph_evidence.txt').read())
