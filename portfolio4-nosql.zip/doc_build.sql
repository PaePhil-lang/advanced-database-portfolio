\timing on
DROP SCHEMA IF EXISTS docstore CASCADE; CREATE SCHEMA docstore;
SELECT setseed(0.7);
-- synthetic medical alerts for ~12% of patients
CREATE TEMP TABLE alerts AS
SELECT patient_id,
  (ARRAY['Penicillin allergy','Latex allergy','Hypertension','Diabetes','Asthma','On anticoagulants','Pregnancy'])[1+floor(random()*7)::int] AS alert
FROM patient WHERE random() < 0.12;
CREATE TABLE docstore.patients (_id text PRIMARY KEY, doc jsonb NOT NULL);
INSERT INTO docstore.patients
SELECT p.hospital_no,
 jsonb_strip_nulls(jsonb_build_object(
  '_id', p.hospital_no,
  'name', jsonb_build_object('first', p.first_name, 'last', p.last_name),
  'dob', p.date_of_birth, 'sex', p.sex,
  'contact', jsonb_build_object('phone', p.phone, 'email', p.email,
               'opt_in', jsonb_build_object('sms', p.sms_opt_in, 'email', p.email_opt_in)),
  'guardian', (SELECT jsonb_build_object('_id', g.hospital_no, 'name', g.first_name||' '||g.last_name, 'phone', g.phone)
               FROM patient g WHERE g.patient_id = p.guardian_id),
  'hmo', CASE WHEN p.hmo_id IS NOT NULL THEN jsonb_build_object('provider', h.hmo_name, 'member_no', p.hmo_member_no) END,
  'home_branch', b.branch_name,
  'medical_alerts', (SELECT jsonb_agg(alert) FROM alerts a WHERE a.patient_id = p.patient_id),
  'dental_chart', (SELECT jsonb_object_agg(tooth, hist) FROM (
        SELECT t.tooth_fdi::text AS tooth,
               jsonb_agg(jsonb_build_object('date', (a.start_at AT TIME ZONE 'Africa/Lagos')::date, 'code', t.service_code,
                                            'surface', t.surface) ORDER BY a.start_at) AS hist
        FROM appointment a JOIN treatment t ON t.appointment_id = a.appointment_id
        WHERE a.patient_id = p.patient_id AND t.tooth_fdi IS NOT NULL GROUP BY t.tooth_fdi) x),
  'visits', (SELECT jsonb_agg(v ORDER BY v->>'date' DESC) FROM (
        SELECT jsonb_build_object('date', (a.start_at AT TIME ZONE 'Africa/Lagos')::date, 'branch', br.branch_name,
               'dentist', 'Dr '||s.last_name, 'status', a.status,
               'procedures', (SELECT jsonb_agg(jsonb_build_object('code', t.service_code, 'tooth', t.tooth_fdi, 'fee', t.fee_charged))
                              FROM treatment t WHERE t.appointment_id = a.appointment_id)) AS v
        FROM appointment a JOIN staff s ON s.staff_id = a.dentist_id JOIN branch br ON br.branch_id = a.branch_id
        WHERE a.patient_id = p.patient_id) y),
  'registered', jsonb_build_object('branch', b.branch_name, 'on', p.registered_on),
  'schema_version', 1))
FROM patient p JOIN branch b ON b.branch_id = p.registered_branch_id LEFT JOIN hmo_provider h ON h.hmo_id = p.hmo_id;
SELECT count(*) docs, pg_size_pretty(pg_total_relation_size('docstore.patients')) size,
       round(avg(pg_column_size(doc))) avg_bytes, max(jsonb_array_length(coalesce(doc->'visits','[]'))) max_visits FROM docstore.patients;
