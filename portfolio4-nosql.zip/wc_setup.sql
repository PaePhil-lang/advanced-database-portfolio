DROP SCHEMA IF EXISTS widecol CASCADE; CREATE SCHEMA widecol;
CREATE TABLE widecol.appointments_by_branch_day (
  branch_id smallint, day date, start_at timestamptz, appointment_id bigint,
  patient_name text, hospital_no text, dentist text, appt_type text, status text,
  PRIMARY KEY (branch_id, day, start_at, appointment_id)
) PARTITION BY HASH (branch_id, day);
DO $$ BEGIN FOR i IN 0..15 LOOP
  EXECUTE format('CREATE TABLE widecol.abd_p%s PARTITION OF widecol.appointments_by_branch_day FOR VALUES WITH (MODULUS 16, REMAINDER %s)', lpad(i::text,2,'0'), i);
END LOOP; END $$;
INSERT INTO widecol.appointments_by_branch_day
SELECT a.branch_id, (a.start_at AT TIME ZONE 'Africa/Lagos')::date, a.start_at, a.appointment_id,
       p.first_name||' '||p.last_name, p.hospital_no, 'Dr '||s.last_name, a.appt_type, a.status
FROM appointment a JOIN patient p USING (patient_id) JOIN staff s ON s.staff_id = a.dentist_id;
ANALYZE widecol.appointments_by_branch_day;
