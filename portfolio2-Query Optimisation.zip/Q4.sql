-- Q4 Patient treatment history for the dentist's chair-side view
SELECT a.start_at::date AS visit_date, sv.service_name, t.tooth_fdi, t.fee_charged,
       'Dr ' || s.last_name AS dentist
FROM appointment a
JOIN treatment t ON t.appointment_id = a.appointment_id
JOIN service  sv ON sv.service_code = t.service_code
JOIN staff     s ON s.staff_id = a.dentist_id
WHERE a.patient_id = 34398
ORDER BY a.start_at DESC;
