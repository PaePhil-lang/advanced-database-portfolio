-- Q3 Day sheet: one branch's appointments for one day, with patient and dentist
SELECT a.start_at AT TIME ZONE 'Africa/Lagos' AS starts, a.status,
       p.hospital_no, p.first_name || ' ' || p.last_name AS patient,
       'Dr ' || s.last_name AS dentist, a.appt_type
FROM appointment a
JOIN patient p ON p.patient_id = a.patient_id
JOIN staff   s ON s.staff_id   = a.dentist_id
WHERE a.branch_id = 1
  AND a.start_at >= '2026-11-12 00:00+01' AND a.start_at < '2026-11-13 00:00+01'
ORDER BY a.start_at, s.last_name;
