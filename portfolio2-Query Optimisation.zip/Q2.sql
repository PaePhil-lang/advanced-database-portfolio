-- Q2 Name search at the front desk: surname prefix + first name
SELECT patient_id, hospital_no, first_name, last_name, phone, date_of_birth
FROM patient
WHERE lower(last_name) LIKE 'okon%' AND lower(first_name) = 'emeka'
ORDER BY last_name, first_name
LIMIT 20;
