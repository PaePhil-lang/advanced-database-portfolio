-- Q1 Caller lookup: identify a patient from the incoming phone number
SELECT patient_id, hospital_no, first_name, last_name, date_of_birth
FROM patient
WHERE phone = '+2348100041234';
