-- Q8 Recall list (original form): patients whose last completed visit was 6 to 12 months ago
SELECT p.patient_id, p.first_name, p.last_name, p.phone,
       (SELECT max(a.start_at) FROM appointment a
         WHERE a.patient_id = p.patient_id AND a.status = 'COMPLETED') AS last_visit
FROM patient p
WHERE (SELECT max(a.start_at) FROM appointment a
        WHERE a.patient_id = p.patient_id AND a.status = 'COMPLETED')
      BETWEEN TIMESTAMPTZ '2026-11-13' - interval '12 months' AND TIMESTAMPTZ '2026-11-13' - interval '6 months'
ORDER BY last_visit;
