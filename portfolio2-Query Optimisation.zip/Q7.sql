-- Q7 Reminder dispatcher: next batch of queued messages due in the next 24 hours
SELECT r.reminder_id, r.channel, r.send_at, p.phone, p.email
FROM reminder r
JOIN appointment a ON a.appointment_id = r.appointment_id
JOIN patient p ON p.patient_id = a.patient_id
WHERE r.delivery_status = 'QUEUED'
  AND r.send_at < TIMESTAMPTZ '2026-11-13 02:00+01' + interval '24 hours'
ORDER BY r.send_at
LIMIT 200;
