\timing on
SET session_replication_role = replica;  -- bulk load: skip triggers and FK checks
SELECT setseed(0.42);
ALTER TABLE appointment DROP CONSTRAINT ex_dentist_no_overlap, DROP CONSTRAINT ex_patient_no_overlap;

INSERT INTO branch (branch_name, street_address, date_opened) VALUES
 ('Ceddi Plaza','Plot 264 Tafawa Balewa Way, Central Area','2006-03-01'),
 ('Baze University Hospital','Plot 686 Jabi Airport Road bypass','2014-09-01');
INSERT INTO branch_phone VALUES ('09087812031',1,'Main'),('07088495218',1,'Line 2'),('07085151651',1,'Line 3'),('08024046026',2,'Main'),('091309556684',2,'Line 2');
INSERT INTO branch_hours SELECT b, d, '09:00', '19:00' FROM generate_series(1,2) b, generate_series(1,5) d;
INSERT INTO branch_hours SELECT b, 6, '09:00', '16:00' FROM generate_series(1,2) b;
INSERT INTO specialty (specialty_name) VALUES ('General dentistry'),('Orthodontics'),('Oral and maxillofacial surgery'),('Periodontology'),('Paediatric dentistry');

-- 60 staff: 1-20 dentists, rest support
INSERT INTO staff (first_name,last_name,job_role,email,home_branch_id,hire_date)
SELECT (ARRAY['Funke','Kunle','Ngozi','Amaka','Musa','Bola','Chidi','Halima','Tunde','Ifeoma'])[1+(g%10)],
       (ARRAY['Bello','Ade','Eze','Obi','Ibrahim','Okafor','Yusuf','Balogun','Nwosu','Lawal'])[1+((g*7)%10)],
       CASE WHEN g<=20 THEN 'DENTIST' WHEN g<=35 THEN 'NURSE' WHEN g<=50 THEN 'RECEPTION' WHEN g<=55 THEN 'ACCOUNTS' ELSE 'MANAGER' END,
       'staff'||g||'@idealdental.test', 1+(g%2), DATE '2010-01-01' + (g*50)
FROM generate_series(1,60) g;
-- dentists 1-14 general/paediatric resident; 15-20 visiting specialists
INSERT INTO dentist SELECT g, 'MDCN/R/'||(1000+g),
  CASE WHEN g<=12 THEN 1 WHEN g<=14 THEN 5 WHEN g<=16 THEN 2 WHEN g<=18 THEN 3 ELSE 4 END, g>14
FROM generate_series(1,20) g;
-- residents: Mon-Sat at home branch; visitors: 2 days/week alternating branches
INSERT INTO dentist_session (dentist_id,branch_id,day_of_week,start_time,end_time)
SELECT g, 1+(g%2), d, '09:00', CASE WHEN d=6 THEN '16:00'::time ELSE '17:00'::time END
FROM generate_series(1,14) g, generate_series(1,6) d;
INSERT INTO dentist_session (dentist_id,branch_id,day_of_week,start_time,end_time)
SELECT g, b, 1 + ((g + b) % 5), '10:00', '16:00' FROM generate_series(15,20) g, generate_series(1,2) b;

INSERT INTO hmo_provider (hmo_name) SELECT 'HMO '||g FROM generate_series(1,12) g;

-- 80,000 patients registered 2014-2026; ~20% children with guardian; ~35% on an HMO
INSERT INTO patient (hospital_no,first_name,last_name,date_of_birth,sex,phone,email,hmo_id,hmo_member_no,registered_branch_id,registered_on)
SELECT 'IDS-'||lpad(g::text,6,'0'),
  (ARRAY['Amaka','Chidi','Musa','Halima','Tunde','Ifeoma','Bola','Kemi','Emeka','Aisha','Femi','Zainab','Uche','Sade','Yakubu','Ngozi'])[1+floor(random()*16)::int],
  (ARRAY['Obi','Ibrahim','Adeyemi','Okafor','Bello','Eze','Yusuf','Balogun','Nwosu','Lawal','Abubakar','Okonkwo','Adebayo','Danjuma','Ogunleye','Mohammed','Chukwu','Ajayi','Garba','Onyeka'])[1+floor(random()*20)::int],
  CASE WHEN g%5=0 THEN DATE '2010-01-01' + floor(random()*5000)::int ELSE DATE '1950-01-01' + floor(random()*20000)::int END,
  CASE WHEN random()<0.52 THEN 'F' ELSE 'M' END,
  '+234' || (ARRAY['80','81','70','90','91'])[1+floor(random()*5)::int] || lpad(g::text,8,'0'),
  CASE WHEN random()<0.6 THEN 'p'||g||'@mail.test' END,
  CASE WHEN g%3=0 THEN 1+(g%12) END, CASE WHEN g%3=0 THEN 'M'||g END,
  1+(g%2), DATE '2014-01-01' + floor(random()*4700)::int
FROM generate_series(1,80000) g;
UPDATE patient SET guardian_id = patient_id - 1 WHERE patient_id % 5 = 0;

INSERT INTO service_category (category_name) VALUES ('Consultation and diagnosis'),('General'),('Restorative'),('Cosmetic'),('Orthodontic'),('Tooth replacement'),('Paediatric'),('Oral surgery'),('Periodontal');
INSERT INTO service VALUES
 ('GEN-EXM',1,'Examination',10000,20,NULL),('GEN-XRY',1,'Periapical X-ray',8000,10,NULL),('GEN-OPG',1,'Panoramic X-ray',20000,15,NULL),
 ('GEN-SCL',2,'Scale and polish',25000,40,NULL),('GEN-FLU',2,'Fluoride application',8000,15,NULL),('GEN-EXT',2,'Simple extraction',20000,30,NULL),
 ('RES-FIL',3,'Composite filling',25000,40,NULL),('RES-AML',3,'Amalgam filling',18000,40,NULL),('RES-RCT',3,'Root canal treatment',90000,90,NULL),('RES-CRN',3,'Crown',180000,60,NULL),
 ('COS-WHT',4,'Teeth whitening',120000,60,NULL),('COS-VEN',4,'Veneer per tooth',200000,60,NULL),
 ('ORT-CON',5,'Orthodontic consultation',20000,30,2),('ORT-BRC',5,'Fixed braces fitting',450000,90,2),('ORT-ADJ',5,'Braces adjustment',25000,30,2),('ORT-ALN',5,'Clear aligner stage',150000,30,2),
 ('REP-DEN',6,'Partial denture',150000,60,NULL),('REP-BRG',6,'Bridge',350000,90,NULL),('REP-IMP',6,'Implant placement',800000,120,3),
 ('PAE-SEA',7,'Fissure sealant',12000,20,NULL),('PAE-PUL',7,'Pulpotomy',35000,40,NULL),
 ('SUR-EXT',8,'Surgical extraction',60000,60,3),('SUR-WIS',8,'Wisdom tooth removal',90000,60,3),
 ('PER-DEP',9,'Deep cleaning per quadrant',40000,45,4),('PER-GRF',9,'Gum graft',250000,90,4);

-- appointments 2017-01-02 .. 2026-12-31: 40-min grid inside each session, ~55% of slots booked
INSERT INTO appointment (patient_id,dentist_id,branch_id,start_at,end_at,appt_type,booking_channel,status,created_at)
SELECT 1+floor(random()*80000)::int, s.dentist_id, s.branch_id,
       (d + s.start_time + k*interval '40 min') AT TIME ZONE 'Africa/Lagos',
       (d + s.start_time + (k+1)*interval '40 min') AT TIME ZONE 'Africa/Lagos',
       'PLANNED','PHONE','BOOKED',
       ((d + s.start_time) AT TIME ZONE 'Africa/Lagos') - (1+floor(random()*20)::int)*interval '1 day'
FROM generate_series(DATE '2017-01-02', DATE '2026-12-31', interval '1 day') d
JOIN dentist_session s ON s.day_of_week = extract(isodow FROM d)
CROSS JOIN LATERAL generate_series(0, (extract(epoch FROM s.end_time - s.start_time)/2400)::int - 1) k
WHERE random() < 0.55;

-- one patient cannot be in two chairs at once: drop the rare clashes
DELETE FROM appointment a USING (
  SELECT appointment_id, row_number() OVER (PARTITION BY patient_id, start_at ORDER BY appointment_id) rn FROM appointment) x
WHERE a.appointment_id = x.appointment_id AND x.rn > 1;

UPDATE appointment SET
  status = CASE WHEN start_at > TIMESTAMPTZ '2026-11-13 02:00+01' THEN (CASE WHEN random()<0.5 THEN 'BOOKED' ELSE 'CONFIRMED' END)
                ELSE (CASE WHEN random()<0.85 THEN 'COMPLETED' WHEN random()<0.55 THEN 'CANCELLED' ELSE 'NO_SHOW' END) END,
  appt_type = CASE WHEN random()<0.12 THEN 'URGENT' WHEN random()<0.3 THEN 'FOLLOW_UP' ELSE 'PLANNED' END,
  booking_channel = CASE WHEN random()<0.45 THEN 'ONLINE' ELSE 'PHONE' END;
UPDATE appointment SET booking_channel='WALK_IN' WHERE appt_type='URGENT' AND random()<0.5;

-- treatments: 1-3 per completed appointment, matched to dentist specialty
INSERT INTO treatment (appointment_id, service_code, tooth_fdi, fee_charged)
SELECT a.appointment_id, sv.service_code,
       CASE WHEN sv.service_code IN ('GEN-EXM','GEN-OPG','GEN-SCL','ORT-CON','ORT-ADJ','ORT-ALN','COS-WHT') THEN NULL
            ELSE (ARRAY[11,12,13,14,15,16,17,21,22,23,24,25,26,27,31,32,33,34,35,36,37,41,42,43,44,45,46,47])[1+floor(random()*28)::int] END,
       round(sv.standard_fee * (CASE WHEN random()<0.15 THEN 0.9 ELSE 1 END) * (1 + (extract(year FROM a.start_at)-2017)*0.06))
FROM appointment a
JOIN dentist d ON d.staff_id = a.dentist_id
CROSS JOIN LATERAL generate_series(1, 1 + floor(random()*2.2)::int) n
CROSS JOIN LATERAL (
  SELECT service_code, standard_fee FROM service
  WHERE (required_specialty_id = d.specialty_id OR (required_specialty_id IS NULL AND d.specialty_id IN (1,5)))
    AND n > 0
  ORDER BY random() LIMIT 1) sv
WHERE a.status = 'COMPLETED';

-- invoices for completed appointments
INSERT INTO invoice (invoice_no, appointment_id, issue_date, due_date, discount)
SELECT 'INV-'||extract(year FROM a.start_at)||'-'||lpad(row_number() OVER (PARTITION BY extract(year FROM a.start_at) ORDER BY a.appointment_id)::text,6,'0'),
       a.appointment_id, (a.start_at AT TIME ZONE 'Africa/Lagos')::date, (a.start_at AT TIME ZONE 'Africa/Lagos')::date + 14,
       CASE WHEN random()<0.05 THEN 5000 ELSE 0 END
FROM appointment a WHERE a.status='COMPLETED';

-- payments: 93% fully paid (some in two parts), 4% part-paid, 3% unpaid
WITH due AS (
  SELECT i.invoice_id, i.issue_date, sum(t.fee_charged) - i.discount AS amt, random() r
  FROM invoice i JOIN treatment t ON t.appointment_id = i.appointment_id GROUP BY i.invoice_id)
INSERT INTO payment (invoice_id, amount, paid_at, method, reference, received_by)
SELECT invoice_id, part, issue_date + (k*3) * interval '1 day' + interval '13 hours', m,
       CASE WHEN m='CASH' THEN NULL ELSE m||'-'||invoice_id||'-'||k END, 36 + (invoice_id % 15)
FROM (
  SELECT invoice_id, issue_date, k, (ARRAY['CASH','POS','TRANSFER','HMO'])[1+floor(random()*4)::int] m,
         CASE WHEN r < 0.80 THEN amt
              WHEN r < 0.93 THEN round(amt/2) + CASE WHEN k=1 THEN amt - 2*round(amt/2) ELSE 0 END
              ELSE round(amt*0.4) END AS part
  FROM due CROSS JOIN LATERAL generate_series(0, CASE WHEN r>=0.80 AND r<0.93 THEN 1 ELSE 0 END) k
  WHERE r < 0.97 AND amt > 0) x;

-- reminders: SMS 24h before + email 48h before, for all appointments
INSERT INTO reminder (appointment_id, channel, send_at, sent_at, delivery_status)
SELECT a.appointment_id, c.ch, a.start_at - c.lead,
       CASE WHEN a.start_at - c.lead < now() THEN a.start_at - c.lead END,
       CASE WHEN a.start_at - c.lead >= TIMESTAMPTZ '2026-11-13 02:00+01' THEN 'QUEUED'
            WHEN a.status IN ('CANCELLED') THEN 'CANCELLED'
            WHEN random()<0.96 THEN 'DELIVERED' ELSE 'FAILED' END
FROM appointment a CROSS JOIN (VALUES ('SMS', interval '24 hours'), ('EMAIL', interval '48 hours')) c(ch, lead);

SET session_replication_role = origin;
ALTER TABLE appointment
  ADD CONSTRAINT ex_dentist_no_overlap EXCLUDE USING gist (dentist_id WITH =, tstzrange(start_at, end_at) WITH &&) WHERE (status NOT IN ('CANCELLED','NO_SHOW')),
  ADD CONSTRAINT ex_patient_no_overlap EXCLUDE USING gist (patient_id WITH =, tstzrange(start_at, end_at) WITH &&) WHERE (status NOT IN ('CANCELLED','NO_SHOW'));
VACUUM ANALYZE;
SELECT relname, n_live_tup FROM pg_stat_user_tables ORDER BY n_live_tup DESC;
