-- Q8b Recall list rewritten: aggregate once, filter with HAVING, then join
SELECT p.patient_id, p.first_name, p.last_name, p.phone, lv.last_visit
FROM (SELECT patient_id, max(start_at) AS last_visit
      FROM appointment
      WHERE status = 'COMPLETED'
      GROUP BY patient_id
      HAVING max(start_at) BETWEEN TIMESTAMPTZ '2026-11-13' - interval '12 months'
                               AND TIMESTAMPTZ '2026-11-13' - interval '6 months') lv
JOIN patient p ON p.patient_id = lv.patient_id
ORDER BY lv.last_visit;
