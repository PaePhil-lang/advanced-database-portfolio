\timing on
CREATE INDEX ix_patient_phone       ON patient (phone);
CREATE INDEX ix_patient_name        ON patient (lower(last_name) text_pattern_ops, lower(first_name));
CREATE INDEX ix_appt_branch_start   ON appointment (branch_id, start_at);
CREATE INDEX ix_appt_patient_start  ON appointment (patient_id, start_at);
CREATE INDEX ix_appt_completed_last ON appointment (patient_id, start_at) WHERE status = 'COMPLETED';
CREATE INDEX ix_appt_start_brin     ON appointment USING brin (start_at);
CREATE INDEX ix_treat_appt          ON treatment (appointment_id) INCLUDE (service_code, fee_charged);
CREATE INDEX ix_reminder_queue      ON reminder (send_at) WHERE delivery_status = 'QUEUED';
CREATE MATERIALIZED VIEW mv_invoice_balance AS SELECT * FROM v_invoice_balance;
CREATE UNIQUE INDEX ux_mv_invoice ON mv_invoice_balance (invoice_id);
CREATE INDEX ix_mv_debtors ON mv_invoice_balance (balance DESC) WHERE balance > 0;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_invoice_balance;
VACUUM ANALYZE;
SELECT indexrelname, pg_size_pretty(pg_relation_size(indexrelid)) FROM pg_stat_user_indexes
WHERE indexrelname LIKE 'ix_%' OR indexrelname LIKE 'ux_%' ORDER BY 1;
SELECT pg_size_pretty(pg_relation_size('appointment')) appt_heap, pg_size_pretty(pg_relation_size('mv_invoice_balance')) mv;
