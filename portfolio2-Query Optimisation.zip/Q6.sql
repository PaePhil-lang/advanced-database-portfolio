-- Q6 Revenue report: 2025 treatment revenue by branch, month and service category
SELECT br.branch_name, date_trunc('month', a.start_at AT TIME ZONE 'Africa/Lagos') AS month,
       sc.category_name, count(*) AS procedures, sum(t.fee_charged) AS revenue
FROM appointment a
JOIN treatment t ON t.appointment_id = a.appointment_id
JOIN service sv ON sv.service_code = t.service_code
JOIN service_category sc ON sc.category_id = sv.category_id
JOIN branch br ON br.branch_id = a.branch_id
WHERE a.status = 'COMPLETED'
  AND a.start_at >= '2025-01-01 00:00+01' AND a.start_at < '2026-01-01 00:00+01'
GROUP BY br.branch_name, month, sc.category_name
ORDER BY br.branch_name, month, revenue DESC;
