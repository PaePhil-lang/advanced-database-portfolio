import subprocess, json, sys, statistics, re, pathlib
DB = sys.argv[1]; label = sys.argv[2]; files = sys.argv[3:]
def psql(sql):
    r = subprocess.run(['su','postgres','-c',f"psql -h /tmp/pg -d {DB} -At -v ON_ERROR_STOP=1"], input=sql, capture_output=True, text=True)
    if r.returncode: raise SystemExit(r.stderr)
    return r.stdout
out = {}
for f in files:
    q = pathlib.Path(f).read_text()
    body = re.sub(r'^--.*\n', '', q, flags=re.M).strip().rstrip(';')
    times = []; plan = None
    for i in range(6):
        j = json.loads(psql(f"EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) {body};"))[0]
        if i: times.append(j['Execution Time'] + j['Planning Time'])
        plan = j
    txt = psql(f"EXPLAIN (ANALYZE, BUFFERS, COSTS OFF, TIMING ON, SUMMARY ON) {body};")
    rows = plan['Plan']['Actual Rows']
    sb = plan['Plan'].get('Shared Hit Blocks',0)+plan['Plan'].get('Shared Read Blocks',0)
    name = pathlib.Path(f).stem
    out[name] = dict(median_ms=round(statistics.median(times),2), rows=rows, buffers=sb, est_cost=plan['Plan']['Total Cost'])
    pathlib.Path(f'plans/{label}_{name}.txt').write_text(txt)
    print(name, out[name], flush=True)
pathlib.Path(f'results_{label}.json').write_text(json.dumps(out, indent=1))
