-- Q6b Revenue report served from a monthly summary refreshed nightly
SELECT br.branch_name, m.month, sc.category_name, m.procedures, m.revenue
FROM mv_monthly_revenue m
JOIN branch br ON br.branch_id = m.branch_id
JOIN service_category sc ON sc.category_id = m.category_id
WHERE m.month >= DATE '2025-01-01' AND m.month < DATE '2026-01-01'
ORDER BY br.branch_name, m.month, m.revenue DESC;
