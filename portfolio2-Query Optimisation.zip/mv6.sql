\timing on
CREATE MATERIALIZED VIEW mv_monthly_revenue AS
SELECT a.branch_id, date_trunc('month', a.start_at AT TIME ZONE 'Africa/Lagos')::date AS month,
       sv.category_id, count(*) AS procedures, sum(t.fee_charged) AS revenue
FROM appointment a
JOIN treatment t ON t.appointment_id = a.appointment_id
JOIN service sv ON sv.service_code = t.service_code
WHERE a.status = 'COMPLETED'
GROUP BY 1, 2, 3;
CREATE UNIQUE INDEX ux_mv_revenue ON mv_monthly_revenue (month, branch_id, category_id);
ANALYZE mv_monthly_revenue;
SELECT count(*) FROM mv_monthly_revenue;
