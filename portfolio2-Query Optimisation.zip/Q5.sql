-- Q5 Debtors list: invoices with an unpaid balance, largest first
SELECT b.invoice_no, p.hospital_no, p.last_name, b.amount_due, b.amount_paid, b.balance
FROM v_invoice_balance b
JOIN patient p ON p.patient_id = b.patient_id
WHERE b.balance > 0 AND b.payment_status <> 'VOID'
ORDER BY b.balance DESC
LIMIT 50;
