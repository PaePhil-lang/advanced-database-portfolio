\timing on
SET session_replication_role = replica;
CREATE INDEX tmp_ap ON appointment (patient_id, start_at);
DELETE FROM appointment a WHERE EXISTS (
  SELECT 1 FROM appointment b WHERE b.patient_id = a.patient_id AND b.appointment_id < a.appointment_id
   AND b.start_at < a.end_at AND a.start_at < b.end_at);
DROP INDEX tmp_ap;
-- remove children of deleted appointments
DELETE FROM reminder r WHERE NOT EXISTS (SELECT 1 FROM appointment a WHERE a.appointment_id=r.appointment_id);
DELETE FROM payment p USING invoice i WHERE p.invoice_id=i.invoice_id AND NOT EXISTS (SELECT 1 FROM appointment a WHERE a.appointment_id=i.appointment_id);
DELETE FROM invoice i WHERE NOT EXISTS (SELECT 1 FROM appointment a WHERE a.appointment_id=i.appointment_id);
DELETE FROM treatment t WHERE NOT EXISTS (SELECT 1 FROM appointment a WHERE a.appointment_id=t.appointment_id);
SET session_replication_role = origin;
ALTER TABLE appointment
  ADD CONSTRAINT ex_dentist_no_overlap EXCLUDE USING gist (dentist_id WITH =, tstzrange(start_at, end_at) WITH &&) WHERE (status NOT IN ('CANCELLED','NO_SHOW')),
  ADD CONSTRAINT ex_patient_no_overlap EXCLUDE USING gist (patient_id WITH =, tstzrange(start_at, end_at) WITH &&) WHERE (status NOT IN ('CANCELLED','NO_SHOW'));
VACUUM ANALYZE;
SELECT relname, n_live_tup, pg_size_pretty(pg_total_relation_size(relid)) FROM pg_stat_user_tables ORDER BY n_live_tup DESC;
SELECT indexrelname FROM pg_stat_user_indexes ORDER BY 1;
