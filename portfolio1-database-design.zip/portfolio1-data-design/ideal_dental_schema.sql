-- Ideal Dental Services: physical schema (PostgreSQL 16)
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- ---------- Branches and staff ----------
CREATE TABLE branch (
  branch_id      SMALLINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  branch_name    VARCHAR(60)  NOT NULL UNIQUE,
  street_address VARCHAR(200) NOT NULL,
  city           VARCHAR(40)  NOT NULL DEFAULT 'Abuja',
  state          VARCHAR(40)  NOT NULL DEFAULT 'FCT',
  date_opened    DATE
);

CREATE TABLE branch_phone (
  phone_number VARCHAR(15) PRIMARY KEY,
  branch_id    SMALLINT NOT NULL REFERENCES branch ON DELETE CASCADE,
  line_label   VARCHAR(20)
);

CREATE TABLE branch_hours (
  branch_id   SMALLINT NOT NULL REFERENCES branch ON DELETE CASCADE,
  day_of_week SMALLINT NOT NULL CONSTRAINT ck_hours_day CHECK (day_of_week BETWEEN 1 AND 7),
  open_time   TIME NOT NULL,
  close_time  TIME NOT NULL,
  PRIMARY KEY (branch_id, day_of_week),
  CONSTRAINT ck_hours_order CHECK (close_time > open_time)
);

CREATE TABLE specialty (
  specialty_id   SMALLINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  specialty_name VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE staff (
  staff_id       INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  first_name     VARCHAR(60) NOT NULL,
  last_name      VARCHAR(60) NOT NULL,
  job_role       VARCHAR(10) NOT NULL CONSTRAINT ck_staff_role
                 CHECK (job_role IN ('DENTIST','NURSE','HYGIENIST','RECEPTION','MANAGER','ACCOUNTS')),
  email          VARCHAR(120) NOT NULL UNIQUE,
  phone          VARCHAR(15),
  hire_date      DATE NOT NULL DEFAULT CURRENT_DATE,
  home_branch_id SMALLINT NOT NULL REFERENCES branch ON DELETE RESTRICT,
  is_active      BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE dentist (
  staff_id        INT PRIMARY KEY REFERENCES staff ON DELETE CASCADE,
  mdcn_licence_no VARCHAR(20) NOT NULL UNIQUE,
  specialty_id    SMALLINT NOT NULL REFERENCES specialty ON DELETE RESTRICT,
  is_visiting     BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE dentist_session (
  session_id  INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  dentist_id  INT NOT NULL REFERENCES dentist ON DELETE CASCADE,
  branch_id   SMALLINT NOT NULL REFERENCES branch ON DELETE CASCADE,
  day_of_week SMALLINT NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
  start_time  TIME NOT NULL,
  end_time    TIME NOT NULL,
  CONSTRAINT ck_session_order CHECK (end_time > start_time),
  UNIQUE (dentist_id, day_of_week, start_time)
);

-- ---------- Patients ----------
CREATE TABLE hmo_provider (
  hmo_id   INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  hmo_name VARCHAR(80) NOT NULL UNIQUE,
  phone    VARCHAR(15),
  email    VARCHAR(120)
);

CREATE TABLE patient (
  patient_id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  hospital_no          VARCHAR(12) NOT NULL UNIQUE CHECK (hospital_no ~ '^IDS-[0-9]{6}$'),
  first_name           VARCHAR(60) NOT NULL,
  last_name            VARCHAR(60) NOT NULL,
  date_of_birth        DATE NOT NULL CONSTRAINT ck_patient_dob CHECK (date_of_birth <= CURRENT_DATE),
  sex                  CHAR(1) NOT NULL CONSTRAINT ck_patient_sex CHECK (sex IN ('M','F')),
  phone                VARCHAR(15) NOT NULL CONSTRAINT ck_patient_phone CHECK (phone ~ '^\+234[789][01][0-9]{8}$'),
  email                VARCHAR(120) UNIQUE,
  address              VARCHAR(200),
  guardian_id          BIGINT REFERENCES patient ON DELETE SET NULL,
  hmo_id               INT REFERENCES hmo_provider ON DELETE SET NULL,
  hmo_member_no        VARCHAR(30),
  registered_branch_id SMALLINT NOT NULL REFERENCES branch ON DELETE RESTRICT,
  registered_on        DATE NOT NULL DEFAULT CURRENT_DATE,
  sms_opt_in           BOOLEAN NOT NULL DEFAULT TRUE,
  email_opt_in         BOOLEAN NOT NULL DEFAULT TRUE,
  CONSTRAINT ck_guardian_not_self CHECK (guardian_id <> patient_id),
  CONSTRAINT ck_hmo_pair CHECK ((hmo_id IS NULL) = (hmo_member_no IS NULL)),
  UNIQUE (hmo_id, hmo_member_no)
);

-- ---------- Clinical ----------
CREATE TABLE service_category (
  category_id   SMALLINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  category_name VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE service (
  service_code          VARCHAR(10) PRIMARY KEY,
  category_id           SMALLINT NOT NULL REFERENCES service_category ON UPDATE CASCADE ON DELETE RESTRICT,
  service_name          VARCHAR(100) NOT NULL UNIQUE,
  standard_fee          NUMERIC(12,2) NOT NULL,
  duration_min          SMALLINT NOT NULL,
  required_specialty_id SMALLINT REFERENCES specialty ON DELETE SET NULL,
  CONSTRAINT ck_service_fee CHECK (standard_fee >= 0 AND duration_min BETWEEN 5 AND 480)
);

CREATE TABLE treatment_plan (
  plan_id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  patient_id      BIGINT NOT NULL REFERENCES patient ON DELETE RESTRICT,
  lead_dentist_id INT NOT NULL REFERENCES dentist ON DELETE RESTRICT,
  title           VARCHAR(100) NOT NULL,
  start_date      DATE NOT NULL DEFAULT CURRENT_DATE,
  target_end_date DATE,
  status          VARCHAR(10) NOT NULL DEFAULT 'ACTIVE'
                  CHECK (status IN ('ACTIVE','ON_HOLD','COMPLETED','ABANDONED')),
  CONSTRAINT ck_plan_dates CHECK (target_end_date IS NULL OR target_end_date >= start_date)
);

CREATE TABLE appointment (
  appointment_id  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  patient_id      BIGINT NOT NULL REFERENCES patient ON DELETE RESTRICT,
  dentist_id      INT NOT NULL REFERENCES dentist ON DELETE RESTRICT,
  branch_id       SMALLINT NOT NULL REFERENCES branch ON DELETE RESTRICT,
  start_at        TIMESTAMPTZ NOT NULL,
  end_at          TIMESTAMPTZ NOT NULL,
  appt_type       VARCHAR(10) NOT NULL CONSTRAINT ck_appt_type CHECK (appt_type IN ('PLANNED','URGENT','FOLLOW_UP')),
  booking_channel VARCHAR(8)  NOT NULL CONSTRAINT ck_appt_channel CHECK (booking_channel IN ('ONLINE','PHONE','WALK_IN')),
  status          VARCHAR(10) NOT NULL DEFAULT 'BOOKED' CONSTRAINT ck_appt_status
                  CHECK (status IN ('BOOKED','CONFIRMED','ARRIVED','COMPLETED','CANCELLED','NO_SHOW')),
  reason          VARCHAR(250),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT ck_appt_order CHECK (end_at > start_at),
  CONSTRAINT ck_appt_same_day CHECK ((start_at AT TIME ZONE 'Africa/Lagos')::date = (end_at AT TIME ZONE 'Africa/Lagos')::date),
  CONSTRAINT ck_walkin_urgent CHECK (booking_channel <> 'WALK_IN' OR appt_type = 'URGENT'),
  CONSTRAINT ex_dentist_no_overlap EXCLUDE USING gist
    (dentist_id WITH =, tstzrange(start_at, end_at) WITH &&)
    WHERE (status NOT IN ('CANCELLED','NO_SHOW')),
  CONSTRAINT ex_patient_no_overlap EXCLUDE USING gist
    (patient_id WITH =, tstzrange(start_at, end_at) WITH &&)
    WHERE (status NOT IN ('CANCELLED','NO_SHOW'))
);

CREATE TABLE treatment (
  treatment_id   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  appointment_id BIGINT NOT NULL REFERENCES appointment ON DELETE CASCADE,
  service_code   VARCHAR(10) NOT NULL REFERENCES service ON UPDATE CASCADE ON DELETE RESTRICT,
  plan_id        BIGINT REFERENCES treatment_plan ON DELETE SET NULL,
  tooth_fdi      SMALLINT CONSTRAINT ck_tooth_fdi CHECK (tooth_fdi BETWEEN 11 AND 48 OR tooth_fdi BETWEEN 51 AND 85),
  surface        VARCHAR(5) CHECK (surface ~ '^[MODBLI]{1,5}$'),
  fee_charged    NUMERIC(12,2) NOT NULL CONSTRAINT ck_fee_charged CHECK (fee_charged >= 0),
  clinical_notes TEXT
);

-- ---------- Billing and communication ----------
CREATE TABLE invoice (
  invoice_id     BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  invoice_no     VARCHAR(16) NOT NULL UNIQUE CHECK (invoice_no ~ '^INV-[0-9]{4}-[0-9]{6}$'),
  appointment_id BIGINT NOT NULL UNIQUE REFERENCES appointment ON DELETE RESTRICT,
  issue_date     DATE NOT NULL DEFAULT CURRENT_DATE,
  due_date       DATE NOT NULL DEFAULT CURRENT_DATE,
  discount       NUMERIC(12,2) NOT NULL DEFAULT 0,
  status         VARCHAR(6) NOT NULL DEFAULT 'ISSUED' CHECK (status IN ('ISSUED','VOID')),
  CONSTRAINT ck_invoice_dates CHECK (due_date >= issue_date AND discount >= 0)
);

CREATE TABLE payment (
  payment_id  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  invoice_id  BIGINT NOT NULL REFERENCES invoice ON DELETE RESTRICT,
  amount      NUMERIC(12,2) NOT NULL CONSTRAINT ck_payment_amount CHECK (amount > 0),
  paid_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  method      VARCHAR(10) NOT NULL CHECK (method IN ('CASH','POS','TRANSFER','HMO')),
  reference   VARCHAR(40),
  received_by INT NOT NULL REFERENCES staff ON DELETE RESTRICT,
  CONSTRAINT ck_payment_ref CHECK (method = 'CASH' OR reference IS NOT NULL),
  UNIQUE (method, reference)
);

CREATE TABLE reminder (
  reminder_id     BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  appointment_id  BIGINT NOT NULL REFERENCES appointment ON DELETE CASCADE,
  channel         VARCHAR(5) NOT NULL,
  send_at         TIMESTAMPTZ NOT NULL,
  sent_at         TIMESTAMPTZ,
  delivery_status VARCHAR(10) NOT NULL DEFAULT 'QUEUED',
  CONSTRAINT ck_reminder_channel CHECK (channel IN ('SMS','EMAIL')
    AND delivery_status IN ('QUEUED','SENT','DELIVERED','FAILED','CANCELLED')),
  UNIQUE (appointment_id, channel, send_at)
);

-- ---------- Indexes on foreign keys used for lookups ----------
CREATE INDEX ix_appt_patient   ON appointment (patient_id, start_at);
CREATE INDEX ix_appt_branch    ON appointment (branch_id, start_at);
CREATE INDEX ix_treat_appt     ON treatment (appointment_id);
CREATE INDEX ix_treat_plan     ON treatment (plan_id);
CREATE INDEX ix_payment_inv    ON payment (invoice_id);
CREATE INDEX ix_reminder_queue ON reminder (send_at) WHERE delivery_status = 'QUEUED';

-- ---------- Views for derived values ----------
CREATE VIEW v_invoice_balance AS
SELECT i.invoice_id, i.invoice_no, a.patient_id,
       COALESCE(t.total, 0) - i.discount               AS amount_due,
       COALESCE(p.paid, 0)                             AS amount_paid,
       COALESCE(t.total, 0) - i.discount - COALESCE(p.paid, 0) AS balance,
       CASE WHEN i.status = 'VOID' THEN 'VOID'
            WHEN COALESCE(p.paid, 0) = 0 THEN 'UNPAID'
            WHEN COALESCE(p.paid, 0) < COALESCE(t.total, 0) - i.discount THEN 'PART_PAID'
            ELSE 'PAID' END                            AS payment_status
FROM invoice i
JOIN appointment a ON a.appointment_id = i.appointment_id
LEFT JOIN (SELECT appointment_id, SUM(fee_charged) total FROM treatment GROUP BY appointment_id) t
       ON t.appointment_id = i.appointment_id
LEFT JOIN (SELECT invoice_id, SUM(amount) paid FROM payment GROUP BY invoice_id) p
       ON p.invoice_id = i.invoice_id;

CREATE VIEW v_patient AS
SELECT p.*, date_part('year', age(p.date_of_birth))::int AS age_years
FROM patient p;

-- ---------- Triggers for cross-row business rules ----------
-- BR1, BR4, BR8: inside branch hours and the dentist's rostered session
CREATE FUNCTION fn_appt_slot_valid() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  s timestamp := NEW.start_at AT TIME ZONE 'Africa/Lagos';
  e timestamp := NEW.end_at   AT TIME ZONE 'Africa/Lagos';
  d smallint  := EXTRACT(ISODOW FROM s);
BEGIN
  IF NOT EXISTS (SELECT 1 FROM branch_hours h
                 WHERE h.branch_id = NEW.branch_id AND h.day_of_week = d
                   AND s::time >= h.open_time AND e::time <= h.close_time) THEN
    RAISE EXCEPTION 'Appointment falls outside opening hours of branch %', NEW.branch_id;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM dentist_session ds
                 WHERE ds.dentist_id = NEW.dentist_id AND ds.branch_id = NEW.branch_id
                   AND ds.day_of_week = d
                   AND s::time >= ds.start_time AND e::time <= ds.end_time) THEN
    RAISE EXCEPTION 'Dentist % is not rostered at branch % at that time', NEW.dentist_id, NEW.branch_id;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_appt_slot BEFORE INSERT OR UPDATE OF start_at, end_at, dentist_id, branch_id
  ON appointment FOR EACH ROW EXECUTE FUNCTION fn_appt_slot_valid();

-- BR3, BR9, BR10: specialty required by the service, plan belongs to same patient
CREATE FUNCTION fn_treatment_valid() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE req smallint; spec smallint; appt_patient bigint; plan_patient bigint;
BEGIN
  SELECT s.required_specialty_id INTO req FROM service s WHERE s.service_code = NEW.service_code;
  SELECT d.specialty_id, a.patient_id INTO spec, appt_patient
    FROM appointment a JOIN dentist d ON d.staff_id = a.dentist_id
   WHERE a.appointment_id = NEW.appointment_id;
  IF req IS NOT NULL AND req <> spec THEN
    RAISE EXCEPTION 'Service % requires specialty %', NEW.service_code, req;
  END IF;
  IF NEW.plan_id IS NOT NULL THEN
    SELECT patient_id INTO plan_patient FROM treatment_plan WHERE plan_id = NEW.plan_id;
    IF plan_patient <> appt_patient THEN
      RAISE EXCEPTION 'Treatment plan % belongs to another patient', NEW.plan_id;
    END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_treatment_valid BEFORE INSERT OR UPDATE ON treatment
  FOR EACH ROW EXECUTE FUNCTION fn_treatment_valid();

-- BR5: a patient under 18 needs a guardian
CREATE FUNCTION fn_guardian_minor() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF age(NEW.date_of_birth) < interval '18 years' AND NEW.guardian_id IS NULL THEN
    RAISE EXCEPTION 'Patient % is under 18 and needs a guardian', NEW.hospital_no;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_guardian_minor BEFORE INSERT OR UPDATE ON patient
  FOR EACH ROW EXECUTE FUNCTION fn_guardian_minor();

-- BR11: invoice only a completed appointment
CREATE FUNCTION fn_invoice_completed() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF (SELECT status FROM appointment WHERE appointment_id = NEW.appointment_id) <> 'COMPLETED' THEN
    RAISE EXCEPTION 'Appointment % is not completed', NEW.appointment_id;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_invoice_completed BEFORE INSERT ON invoice
  FOR EACH ROW EXECUTE FUNCTION fn_invoice_completed();

-- BR11: payments never exceed the amount due (row lock stops two tills racing)
CREATE FUNCTION fn_payment_cap() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE due numeric; paid numeric;
BEGIN
  PERFORM 1 FROM invoice WHERE invoice_id = NEW.invoice_id FOR UPDATE;
  SELECT amount_due INTO due FROM v_invoice_balance WHERE invoice_id = NEW.invoice_id;
  SELECT COALESCE(SUM(amount), 0) INTO paid FROM payment
   WHERE invoice_id = NEW.invoice_id AND payment_id IS DISTINCT FROM NEW.payment_id;
  IF paid + NEW.amount > due THEN
    RAISE EXCEPTION 'Payment exceeds balance: due %, already paid %', due, paid;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_payment_cap BEFORE INSERT OR UPDATE ON payment
  FOR EACH ROW EXECUTE FUNCTION fn_payment_cap();

-- BR12: cancelling an appointment cancels its queued reminders
CREATE FUNCTION fn_cancel_reminders() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  UPDATE reminder SET delivery_status = 'CANCELLED'
   WHERE appointment_id = NEW.appointment_id AND delivery_status = 'QUEUED';
  RETURN NEW;
END $$;
CREATE TRIGGER trg_cancel_reminders AFTER UPDATE OF status ON appointment
  FOR EACH ROW WHEN (NEW.status IN ('CANCELLED','NO_SHOW'))
  EXECUTE FUNCTION fn_cancel_reminders();
