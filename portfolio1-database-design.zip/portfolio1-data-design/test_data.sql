\set ON_ERROR_STOP 0
INSERT INTO branch (branch_name, street_address) VALUES
 ('Ceddi Plaza','Plot 264 Tafawa Balewa Way, Central Area'),
 ('Baze University Hospital','Plot 686 Jabi Airport Road bypass');
INSERT INTO branch_phone VALUES ('09087812031',1,'Main'),('08024046026',2,'Main');
INSERT INTO branch_hours SELECT b, d, '09:00', '19:00' FROM generate_series(1,2) b, generate_series(1,5) d;
INSERT INTO branch_hours SELECT b, 6, '09:00', '16:00' FROM generate_series(1,2) b;
INSERT INTO specialty (specialty_name) VALUES ('General dentistry'),('Orthodontics'),('Oral and maxillofacial surgery'),('Periodontology'),('Paediatric dentistry');
INSERT INTO staff (first_name,last_name,job_role,email,home_branch_id) VALUES
 ('Funke','Bello','DENTIST','f.bello@ids.test',1),('Kunle','Ade','DENTIST','k.ade@ids.test',2),('Ngozi','Eze','RECEPTION','n.eze@ids.test',1);
INSERT INTO dentist VALUES (1,'MDCN/R/1234',1,false),(2,'MDCN/R/5678',2,true);
INSERT INTO dentist_session (dentist_id,branch_id,day_of_week,start_time,end_time) VALUES
 (1,1,4,'09:00','17:00'),(2,2,4,'10:00','14:00');
INSERT INTO service_category (category_name) VALUES ('General'),('Restorative'),('Orthodontic');
INSERT INTO service VALUES ('GEN-EXM',1,'Examination',10000,20,NULL),('RES-FIL',2,'Composite filling',25000,40,NULL),('ORT-BRC',3,'Fixed braces fitting',450000,90,2);
-- adult
INSERT INTO patient (hospital_no,first_name,last_name,date_of_birth,sex,phone,registered_branch_id)
 VALUES ('IDS-000100','Chidi','Obi','1985-01-01','M','+2348035550000',1);
-- minor without guardian: should FAIL
INSERT INTO patient (hospital_no,first_name,last_name,date_of_birth,sex,phone,registered_branch_id)
 VALUES ('IDS-000231','Amaka','Obi','2016-03-12','F','+2348031112233',1);
-- minor with guardian: ok
INSERT INTO patient (hospital_no,first_name,last_name,date_of_birth,sex,phone,registered_branch_id,guardian_id)
 VALUES ('IDS-000231','Amaka','Obi','2016-03-12','F','+2348031112233',1,1);
-- Thursday 12 Nov 2026 10:00 Lagos: ok
INSERT INTO appointment (patient_id,dentist_id,branch_id,start_at,end_at,appt_type,booking_channel)
 VALUES (3,1,1,'2026-11-12 10:00+01','2026-11-12 10:40+01','PLANNED','ONLINE');
-- overlap for dentist 1: should FAIL
INSERT INTO appointment (patient_id,dentist_id,branch_id,start_at,end_at,appt_type,booking_channel)
 VALUES (1,1,1,'2026-11-12 10:20+01','2026-11-12 10:50+01','PLANNED','PHONE');
-- Sunday: should FAIL
INSERT INTO appointment (patient_id,dentist_id,branch_id,start_at,end_at,appt_type,booking_channel)
 VALUES (1,1,1,'2026-11-15 10:00+01','2026-11-15 10:30+01','PLANNED','PHONE');
-- dentist 2 not rostered at branch 1: should FAIL
INSERT INTO appointment (patient_id,dentist_id,branch_id,start_at,end_at,appt_type,booking_channel)
 VALUES (1,2,1,'2026-11-12 11:00+01','2026-11-12 11:30+01','PLANNED','PHONE');
-- braces by general dentist: should FAIL
INSERT INTO treatment (appointment_id,service_code,fee_charged) VALUES (1,'ORT-BRC',450000);
INSERT INTO treatment (appointment_id,service_code,fee_charged) VALUES (1,'GEN-EXM',10000);
INSERT INTO treatment (appointment_id,service_code,tooth_fdi,surface,fee_charged) VALUES (1,'RES-FIL',75,'O',22500);
INSERT INTO reminder (appointment_id,channel,send_at) VALUES (1,'SMS','2026-11-11 09:00+01');
-- invoice before completion: should FAIL
INSERT INTO invoice (invoice_no,appointment_id) VALUES ('INV-2026-000412',1);
UPDATE appointment SET status='COMPLETED' WHERE appointment_id=1;
INSERT INTO invoice (invoice_no,appointment_id,discount) VALUES ('INV-2026-000412',1,0);
INSERT INTO payment (invoice_id,amount,method,reference,received_by) VALUES ((SELECT invoice_id FROM invoice),15000,'POS','POS-001',3);
-- overpay: should FAIL
INSERT INTO payment (invoice_id,amount,method,received_by) VALUES ((SELECT invoice_id FROM invoice),20000,'CASH',3);
INSERT INTO payment (invoice_id,amount,method,reference,received_by) VALUES ((SELECT invoice_id FROM invoice),17500,'TRANSFER','TRF-9',3);
SELECT * FROM v_invoice_balance;
-- cancel test
INSERT INTO appointment (patient_id,dentist_id,branch_id,start_at,end_at,appt_type,booking_channel)
 VALUES (1,2,2,'2026-11-19 11:00+01','2026-11-19 11:30+01','PLANNED','PHONE');
INSERT INTO reminder (appointment_id,channel,send_at) VALUES (currval('appointment_appointment_id_seq'),'EMAIL','2026-11-18 09:00+01');
UPDATE appointment SET status='CANCELLED' WHERE appointment_id=currval('appointment_appointment_id_seq');
SELECT reminder_id, delivery_status FROM reminder;
SELECT hospital_no, age_years FROM v_patient;
